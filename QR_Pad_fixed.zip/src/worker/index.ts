import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { cors } from "hono/cors";
import QRCode from 'qrcode';
import { CreateQRCodeSchema, CreateCustomCategorySchema } from "@/shared/types";

const app = new Hono<{ Bindings: Env }>();

app.use('*', cors());

// Get all QR codes
app.get('/api/qr-codes', async (c) => {
  try {
    const db = c.env.DB;
    const result = await db.prepare(`
      SELECT * FROM qr_codes 
      ORDER BY created_at DESC
    `).all();
    
    return c.json({ qrCodes: result.results });
  } catch (error) {
    console.error('Error fetching QR codes:', error);
    return c.json({ error: 'Failed to fetch QR codes' }, 500);
  }
});

// Create new QR code
app.post('/api/qr-codes', zValidator('json', CreateQRCodeSchema), async (c) => {
  try {
    const data = c.req.valid('json');
    const db = c.env.DB;
    
    // Generate QR code image with customizations
    const qrOptions: any = {
      color: {
        dark: data.custom_color,
        light: data.background_color || '#FFFFFF'
      },
      width: 300,
      margin: 2,
      errorCorrectionLevel: 'M'
    };

    // Apply style customizations
    if (data.qr_style === 'rounded') {
      qrOptions.rendererOpts = { 
        ...qrOptions.rendererOpts,
        moduleSize: 4,
        margin: 3
      };
    }

    const qrDataUrl = await QRCode.toDataURL(data.content, qrOptions);
    
    // Hash password if provided
    let passwordHash = null;
    if (data.is_password_protected && data.password) {
      // Simple hash for demo - in production use proper bcrypt
      passwordHash = btoa(data.password);
    }
    
    const result = await db.prepare(`
      INSERT INTO qr_codes (
        title, content, qr_type, category, custom_category_id, qr_data_url,
        is_password_protected, password_hash, expires_at,
        is_dynamic, geo_latitude, geo_longitude, geo_radius,
        custom_color, custom_logo, qr_style, background_color,
        has_logo, logo_url, border_style, corner_style, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(
      data.title,
      data.content,
      data.qr_type,
      data.category || null,
      data.custom_category_id || null,
      qrDataUrl,
      data.is_password_protected ? 1 : 0,
      passwordHash,
      data.expires_at || null,
      data.is_dynamic ? 1 : 0,
      data.geo_latitude || null,
      data.geo_longitude || null,
      data.geo_radius || null,
      data.custom_color,
      data.custom_logo || null,
      data.qr_style || 'square',
      data.background_color || '#FFFFFF',
      data.has_logo ? 1 : 0,
      data.logo_url || null,
      data.border_style || 'none',
      data.corner_style || 'square'
    ).run();
    
    const qrCode = await db.prepare(`
      SELECT * FROM qr_codes WHERE id = ?
    `).bind(result.meta.last_row_id).first();
    
    return c.json({ qrCode }, 201);
  } catch (error) {
    console.error('Error creating QR code:', error);
    return c.json({ error: 'Failed to create QR code' }, 500);
  }
});

// Get single QR code
app.get('/api/qr-codes/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const db = c.env.DB;
    
    const qrCode = await db.prepare(`
      SELECT * FROM qr_codes WHERE id = ?
    `).bind(id).first();
    
    if (!qrCode) {
      return c.json({ error: 'QR code not found' }, 404);
    }
    
    return c.json({ qrCode });
  } catch (error) {
    console.error('Error fetching QR code:', error);
    return c.json({ error: 'Failed to fetch QR code' }, 500);
  }
});

// Record QR scan
app.post('/api/qr-codes/:id/scan', async (c) => {
  try {
    const id = c.req.param('id');
    const db = c.env.DB;
    
    // Increment scan count
    await db.prepare(`
      UPDATE qr_codes 
      SET scan_count = scan_count + 1, updated_at = datetime('now')
      WHERE id = ?
    `).bind(id).run();
    
    // Record scan event
    await db.prepare(`
      INSERT INTO qr_scans (qr_code_id, scan_location, device_info, updated_at)
      VALUES (?, ?, ?, datetime('now'))
    `).bind(id, null, null).run();
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error recording scan:', error);
    return c.json({ error: 'Failed to record scan' }, 500);
  }
});

// Delete QR code
app.delete('/api/qr-codes/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const db = c.env.DB;
    
    await db.prepare(`DELETE FROM qr_codes WHERE id = ?`).bind(id).run();
    await db.prepare(`DELETE FROM qr_scans WHERE qr_code_id = ?`).bind(id).run();
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error deleting QR code:', error);
    return c.json({ error: 'Failed to delete QR code' }, 500);
  }
});

// Get all custom categories
app.get('/api/custom-categories', async (c) => {
  try {
    const db = c.env.DB;
    const result = await db.prepare(`
      SELECT * FROM custom_categories 
      ORDER BY created_at DESC
    `).all();
    
    return c.json({ categories: result.results });
  } catch (error) {
    console.error('Error fetching custom categories:', error);
    return c.json({ error: 'Failed to fetch custom categories' }, 500);
  }
});

// Create new custom category
app.post('/api/custom-categories', zValidator('json', CreateCustomCategorySchema), async (c) => {
  try {
    const data = c.req.valid('json');
    const db = c.env.DB;
    
    const result = await db.prepare(`
      INSERT INTO custom_categories (name, icon, color, updated_at)
      VALUES (?, ?, ?, datetime('now'))
    `).bind(data.name, data.icon, data.color).run();
    
    const category = await db.prepare(`
      SELECT * FROM custom_categories WHERE id = ?
    `).bind(result.meta.last_row_id).first();
    
    return c.json({ category }, 201);
  } catch (error) {
    console.error('Error creating custom category:', error);
    return c.json({ error: 'Failed to create custom category' }, 500);
  }
});

// Delete custom category
app.delete('/api/custom-categories/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const db = c.env.DB;
    
    // Check if any QR codes use this category
    const qrCodeCount = await db.prepare(`
      SELECT COUNT(*) as count FROM qr_codes WHERE custom_category_id = ?
    `).bind(id).first();
    
    if (qrCodeCount && (qrCodeCount as any).count > 0) {
      return c.json({ error: 'Cannot delete category that is being used by QR codes' }, 400);
    }
    
    await db.prepare(`DELETE FROM custom_categories WHERE id = ?`).bind(id).run();
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error deleting custom category:', error);
    return c.json({ error: 'Failed to delete custom category' }, 500);
  }
});

export default app;
