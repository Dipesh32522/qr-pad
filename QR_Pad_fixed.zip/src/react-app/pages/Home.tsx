import { useState } from 'react';
import { useQRCodes } from '@/react-app/hooks/useQRCodes';
import { QRCodeType, CreateQRCodeType } from '@/shared/types';
import Header from '@/react-app/components/Header';
import QRGenerator from '@/react-app/components/QRGenerator';
import QRLibrary from '@/react-app/components/QRLibrary';
import QRScanner from '@/react-app/components/QRScanner';
import QRModal from '@/react-app/components/QRModal';
import QRResultModal from '@/react-app/components/QRResultModal';
import UserGuideModal from '@/react-app/components/UserGuideModal';
import ContentGuide from '@/react-app/components/ContentGuide';
import BulkQRGenerator from '@/react-app/components/BulkQRGenerator';
import AnalyticsDashboard from '@/react-app/components/AnalyticsDashboard';
import QRTemplates from '@/react-app/components/QRTemplates';
import QRHistory from '@/react-app/components/QRHistory';

export default function Home() {
  const { qrCodes, isLoading, error, createQRCode, deleteQRCode, recordScan } = useQRCodes();
  const [activeTab, setActiveTab] = useState<'generate' | 'library'>('generate');
  const [showScanner, setShowScanner] = useState(false);
  const [selectedQR, setSelectedQR] = useState<QRCodeType | null>(null);
  const [scannedData, setScannedData] = useState<string | null>(null);
  const [notification, setNotification] = useState<string | null>(null);
  const [showGuide, setShowGuide] = useState(false);
  const [showContent, setShowContent] = useState(false);
  const [showBulk, setShowBulk] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  const showNotification = (message: string) => {
    setNotification(message);
    setTimeout(() => setNotification(null), 3000);
  };

  const handleCreateQR = async (qrData: CreateQRCodeType) => {
    const newQR = await createQRCode(qrData);
    if (newQR) {
      showNotification('QR code created successfully!');
      setActiveTab('library');
    }
  };

  const handleDeleteQR = async (id: number) => {
    if (confirm('Are you sure you want to delete this QR code?')) {
      await deleteQRCode(id);
      showNotification('QR code deleted successfully!');
    }
  };

  const handleScan = (data: string) => {
    setShowScanner(false);
    setScannedData(data);
    showNotification('QR Code scanned successfully!');
  };

  const handleViewQR = (qrCode: QRCodeType) => {
    setSelectedQR(qrCode);
  };

  const handleQRScan = (id: number) => {
    recordScan(id);
    setSelectedQR(null);
    showNotification('QR code scanned successfully!');
  };

  const handleBulkGenerate = async (qrDataList: CreateQRCodeType[]) => {
    try {
      const results = await Promise.all(
        qrDataList.map(qrData => createQRCode(qrData))
      );
      const successCount = results.filter(result => result !== null).length;
      setShowBulk(false);
      setActiveTab('library');
      showNotification(`Successfully generated ${successCount} QR codes!`);
    } catch (error) {
      showNotification('Error generating QR codes. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        onNewQR={() => setActiveTab('generate')}
        onScan={() => setShowScanner(true)}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onShowGuide={() => setShowGuide(true)}
        onShowContent={() => setShowContent(true)}
        onShowBulk={() => setShowBulk(true)}
        onShowAnalytics={() => setShowAnalytics(true)}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Error Message */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl">
            <p className="text-red-700">{error}</p>
          </div>
        )}

        {/* Notification */}
        {notification && (
          <div className="fixed top-4 right-4 z-50 p-4 bg-green-50 border border-green-200 rounded-xl shadow-lg">
            <p className="text-green-700 font-medium">{notification}</p>
          </div>
        )}

        {/* Content */}
        {activeTab === 'generate' ? (
          <div className="max-w-2xl mx-auto">
            <QRGenerator
              onGenerate={handleCreateQR}
              isLoading={isLoading}
              onShowTemplates={() => setShowTemplates(true)}
            />
          </div>
        ) : (
          <QRLibrary
            qrCodes={qrCodes}
            onDelete={handleDeleteQR}
            onView={handleViewQR}
            isLoading={isLoading}
            onShowHistory={() => setShowHistory(true)}
          />
        )}
      </main>

      {/* Scanner Modal */}
      {showScanner && (
        <QRScanner
          onScan={handleScan}
          onClose={() => setShowScanner(false)}
        />
      )}

      {/* QR Detail Modal */}
      {selectedQR && (
        <QRModal
          qrCode={selectedQR}
          onClose={() => setSelectedQR(null)}
          onScan={handleQRScan}
        />
      )}

      {/* Scanned QR Result Modal */}
      {scannedData && (
        <QRResultModal
          data={scannedData}
          onClose={() => setScannedData(null)}
        />
      )}

      {/* User Guide Modal */}
      {showGuide && (
        <UserGuideModal
          onClose={() => setShowGuide(false)}
        />
      )}

      {/* Content Guide Modal */}
      {showContent && (
        <ContentGuide
          onClose={() => setShowContent(false)}
        />
      )}

      {/* Bulk QR Generator Modal */}
      {showBulk && (
        <BulkQRGenerator
          onGenerate={handleBulkGenerate}
          isLoading={isLoading}
          onClose={() => setShowBulk(false)}
        />
      )}

      {/* Analytics Dashboard Modal */}
      {showAnalytics && (
        <AnalyticsDashboard
          qrCodes={qrCodes}
          onClose={() => setShowAnalytics(false)}
        />
      )}

      {/* QR Templates Modal */}
      {showTemplates && (
        <QRTemplates
          onUseTemplate={(templateData) => {
            handleCreateQR(templateData);
            setActiveTab('generate');
            setShowTemplates(false);
            showNotification('Template applied successfully!');
          }}
          onClose={() => setShowTemplates(false)}
        />
      )}

      {/* QR History Modal */}
      {showHistory && (
        <QRHistory
          qrCodes={qrCodes}
          onRestore={(qrCode) => {
            const templateData: CreateQRCodeType = {
              title: qrCode.title + ' (Restored)',
              content: qrCode.content,
              qr_type: qrCode.qr_type,
              category: qrCode.category,
              is_password_protected: false,
              is_dynamic: qrCode.is_dynamic,
              custom_color: qrCode.custom_color,
              qr_style: 'square',
              background_color: '#FFFFFF',
              has_logo: false,
              border_style: 'none',
              corner_style: 'square'
            };
            handleCreateQR(templateData);
            setShowHistory(false);
            showNotification('QR code restored successfully!');
          }}
          onDelete={handleDeleteQR}
          onClose={() => setShowHistory(false)}
        />
      )}
    </div>
  );
}
