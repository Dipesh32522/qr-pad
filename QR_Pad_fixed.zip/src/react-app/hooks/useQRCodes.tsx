import { useState, useEffect, useCallback } from 'react';
import { QRCodeType, CreateQRCodeType } from '@/shared/types';

export function useQRCodes() {
  const [qrCodes, setQRCodes] = useState<QRCodeType[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchQRCodes = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await fetch('/api/qr-codes');
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch QR codes');
      }
      
      setQRCodes(data.qrCodes || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      console.error('Error fetching QR codes:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const createQRCode = useCallback(async (qrData: CreateQRCodeType): Promise<QRCodeType | null> => {
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await fetch('/api/qr-codes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(qrData),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to create QR code');
      }
      
      const newQRCode = data.qrCode;
      setQRCodes(prev => [newQRCode, ...prev]);
      return newQRCode;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      console.error('Error creating QR code:', err);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const deleteQRCode = useCallback(async (id: number) => {
    try {
      setError(null);
      
      const response = await fetch(`/api/qr-codes/${id}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to delete QR code');
      }
      
      setQRCodes(prev => prev.filter(qr => qr.id !== id));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      console.error('Error deleting QR code:', err);
    }
  }, []);

  const recordScan = useCallback(async (id: number) => {
    try {
      const response = await fetch(`/api/qr-codes/${id}/scan`, {
        method: 'POST',
      });
      
      if (response.ok) {
        // Update scan count locally
        setQRCodes(prev => prev.map(qr => 
          qr.id === id 
            ? { ...qr, scan_count: qr.scan_count + 1 }
            : qr
        ));
      }
    } catch (err) {
      console.error('Error recording scan:', err);
    }
  }, []);

  useEffect(() => {
    fetchQRCodes();
  }, [fetchQRCodes]);

  return {
    qrCodes,
    isLoading,
    error,
    createQRCode,
    deleteQRCode,
    recordScan,
    refetch: fetchQRCodes
  };
}
