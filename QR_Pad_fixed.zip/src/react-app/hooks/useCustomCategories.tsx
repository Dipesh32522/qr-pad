import { useState, useEffect, useCallback } from 'react';
import { CustomCategoryType, CreateCustomCategoryType } from '@/shared/types';

export function useCustomCategories() {
  const [customCategories, setCustomCategories] = useState<CustomCategoryType[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchCustomCategories = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await fetch('/api/custom-categories');
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch custom categories');
      }
      
      setCustomCategories(data.categories || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      console.error('Error fetching custom categories:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const createCustomCategory = useCallback(async (categoryData: CreateCustomCategoryType): Promise<CustomCategoryType | null> => {
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await fetch('/api/custom-categories', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(categoryData),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to create custom category');
      }
      
      const newCategory = data.category;
      setCustomCategories(prev => [...prev, newCategory]);
      return newCategory;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      console.error('Error creating custom category:', err);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const deleteCustomCategory = useCallback(async (id: number) => {
    try {
      setError(null);
      
      const response = await fetch(`/api/custom-categories/${id}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to delete custom category');
      }
      
      setCustomCategories(prev => prev.filter(cat => cat.id !== id));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      console.error('Error deleting custom category:', err);
    }
  }, []);

  useEffect(() => {
    fetchCustomCategories();
  }, [fetchCustomCategories]);

  return {
    customCategories,
    isLoading,
    error,
    createCustomCategory,
    deleteCustomCategory,
    refetch: fetchCustomCategories
  };
}
