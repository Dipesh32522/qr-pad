import { useState } from 'react';
import { Bookmark, Star, Sparkles, Eye, ArrowRight } from 'lucide-react';
import { CreateQRCodeType } from '@/shared/types';

interface QRTemplatesProps {
  onUseTemplate: (template: CreateQRCodeType) => void;
  onClose: () => void;
}

interface QRTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  icon: string;
  data: CreateQRCodeType;
  isPopular?: boolean;
  isPremium?: boolean;
}

const templates: QRTemplate[] = [
  {
    id: 'business-card',
    name: 'Business Card',
    description: 'Professional contact information with vCard format',
    category: 'Business',
    icon: '💼',
    isPopular: true,
    data: {
      title: 'My Business Card',
      content: 'BEGIN:VCARD\nVERSION:3.0\nFN:John Doe\nORG:Your Company\nTITLE:CEO\nTEL:+1-234-567-8900\nEMAIL:john@company.com\nURL:https://company.com\nEND:VCARD',
      qr_type: 'contact',
      category: 'business',
      is_password_protected: false,
      is_dynamic: false,
      custom_color: '#1f2937',
      background_color: '#ffffff',
      qr_style: 'rounded',
      corner_style: 'rounded',
      border_style: 'thin'
    }
  },
  {
    id: 'wifi-hotspot',
    name: 'WiFi Hotspot',
    description: 'Quick WiFi connection for guests',
    category: 'Networking',
    icon: '📶',
    isPopular: true,
    data: {
      title: 'Guest WiFi Access',
      content: 'WIFI:T:WPA;S:YourNetworkName;P:YourPassword;;',
      qr_type: 'wifi',
      category: 'personal',
      is_password_protected: false,
      is_dynamic: false,
      custom_color: '#059669',
      background_color: '#ffffff',
      qr_style: 'square',
      corner_style: 'rounded',
      border_style: 'none'
    }
  },
  {
    id: 'restaurant-menu',
    name: 'Restaurant Menu',
    description: 'Digital menu with QR code access',
    category: 'Food & Dining',
    icon: '🍽️',
    data: {
      title: 'Our Digital Menu',
      content: 'https://your-restaurant.com/menu',
      qr_type: 'url',
      category: 'business',
      is_password_protected: false,
      is_dynamic: true,
      custom_color: '#dc2626',
      background_color: '#ffffff',
      qr_style: 'rounded',
      corner_style: 'circle',
      border_style: 'thick'
    }
  },
  {
    id: 'social-links',
    name: 'Social Media Hub',
    description: 'All your social media links in one place',
    category: 'Social',
    icon: '🔗',
    isPopular: true,
    data: {
      title: 'My Social Links',
      content: 'https://linktr.ee/yourusername',
      qr_type: 'url',
      category: 'social',
      is_password_protected: false,
      is_dynamic: false,
      custom_color: '#8b5cf6',
      background_color: '#ffffff',
      qr_style: 'circle',
      corner_style: 'circle',
      border_style: 'thin'
    }
  },
  {
    id: 'event-invite',
    name: 'Event Invitation',
    description: 'Share event details and RSVP link',
    category: 'Events',
    icon: '🎉',
    data: {
      title: 'Event Invitation',
      content: 'Join us for our special event!\n\nDate: [Event Date]\nTime: [Event Time]\nLocation: [Event Location]\n\nRSVP: https://your-event.com/rsvp',
      qr_type: 'text',
      category: 'events',
      is_password_protected: false,
      is_dynamic: false,
      custom_color: '#f59e0b',
      background_color: '#ffffff',
      qr_style: 'rounded',
      corner_style: 'square',
      border_style: 'none'
    }
  },
  {
    id: 'product-info',
    name: 'Product Information',
    description: 'Product details, specs, and support',
    category: 'E-commerce',
    icon: '📦',
    data: {
      title: 'Product Details',
      content: 'https://your-store.com/product/12345',
      qr_type: 'url',
      category: 'shopping',
      is_password_protected: false,
      is_dynamic: true,
      custom_color: '#0891b2',
      background_color: '#ffffff',
      qr_style: 'square',
      corner_style: 'rounded',
      border_style: 'thin'
    }
  },
  {
    id: 'feedback-form',
    name: 'Customer Feedback',
    description: 'Collect customer reviews and feedback',
    category: 'Business',
    icon: '📝',
    data: {
      title: 'Share Your Feedback',
      content: 'https://forms.google.com/your-feedback-form',
      qr_type: 'url',
      category: 'business',
      is_password_protected: false,
      is_dynamic: false,
      custom_color: '#7c3aed',
      background_color: '#ffffff',
      qr_style: 'rounded',
      corner_style: 'rounded',
      border_style: 'none'
    }
  },
  {
    id: 'app-download',
    name: 'App Download',
    description: 'Direct link to app store download',
    category: 'Technology',
    icon: '📱',
    isPremium: true,
    data: {
      title: 'Download Our App',
      content: 'https://apps.apple.com/app/your-app-id',
      qr_type: 'url',
      category: 'business',
      is_password_protected: false,
      is_dynamic: false,
      custom_color: '#1f2937',
      background_color: '#ffffff',
      qr_style: 'rounded',
      corner_style: 'circle',
      border_style: 'thick'
    }
  },
  {
    id: 'payment-link',
    name: 'Payment Request',
    description: 'Quick payment link for services',
    category: 'Finance',
    icon: '💳',
    isPremium: true,
    data: {
      title: 'Payment Link',
      content: 'https://pay.stripe.com/your-payment-link',
      qr_type: 'url',
      category: 'business',
      is_password_protected: true,
      password: 'secure123',
      is_dynamic: false,
      custom_color: '#059669',
      background_color: '#ffffff',
      qr_style: 'square',
      corner_style: 'square',
      border_style: 'thick'
    }
  },
  {
    id: 'location-share',
    name: 'Location Share',
    description: 'Share exact location coordinates',
    category: 'Navigation',
    icon: '📍',
    data: {
      title: 'Meet Here',
      content: 'https://maps.google.com/?q=40.7589,-73.9851',
      qr_type: 'url',
      category: 'travel',
      is_password_protected: false,
      is_dynamic: false,
      custom_color: '#dc2626',
      background_color: '#ffffff',
      qr_style: 'circle',
      corner_style: 'circle',
      border_style: 'thin'
    }
  },
  {
    id: 'educational-content',
    name: 'Study Materials',
    description: 'Link to educational resources',
    category: 'Education',
    icon: '📚',
    data: {
      title: 'Course Materials',
      content: 'https://your-school.edu/course/materials',
      qr_type: 'url',
      category: 'study',
      is_password_protected: false,
      is_dynamic: true,
      custom_color: '#7c2d12',
      background_color: '#ffffff',
      qr_style: 'rounded',
      corner_style: 'rounded',
      border_style: 'none'
    }
  },
  {
    id: 'emergency-contact',
    name: 'Emergency Contact',
    description: 'Emergency contact information',
    category: 'Safety',
    icon: '🚨',
    data: {
      title: 'Emergency Contact',
      content: 'In case of emergency, contact:\n\nName: Emergency Contact\nPhone: +1-911-911-9911\nRelation: Guardian\n\nMedical Info: [Medical conditions/allergies]',
      qr_type: 'text',
      category: 'personal',
      is_password_protected: false,
      is_dynamic: false,
      custom_color: '#dc2626',
      background_color: '#ffffff',
      qr_style: 'square',
      corner_style: 'square',
      border_style: 'thick'
    }
  }
];

export default function QRTemplates({ onUseTemplate, onClose }: QRTemplatesProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [previewTemplate, setPreviewTemplate] = useState<QRTemplate | null>(null);

  const categories = ['All', ...Array.from(new Set(templates.map(t => t.category)))];

  const filteredTemplates = templates.filter(template => {
    const matchesCategory = selectedCategory === 'All' || template.category === selectedCategory;
    const matchesSearch = template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleUseTemplate = (template: QRTemplate) => {
    const templateData = { ...template.data };
    // Remove password from template if it exists
    if (templateData.password) {
      delete templateData.password;
    }
    onUseTemplate(templateData);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-7xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
                <Bookmark className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">QR Code Templates</h2>
                <p className="text-indigo-100">Choose from professional pre-made templates</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-indigo-100 hover:text-white hover:bg-white hover:bg-opacity-20 rounded-lg transition-colors"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="p-6 border-b border-gray-200 bg-gray-50">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search templates..."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              />
            </div>
            <div className="flex gap-2 overflow-x-auto">
              {categories.map(category => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-colors ${
                    selectedCategory === category
                      ? 'bg-indigo-500 text-white'
                      : 'bg-white text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Templates Grid */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-300px)]">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredTemplates.map(template => (
              <div key={template.id} className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-all group">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="text-3xl">{template.icon}</div>
                    <div>
                      <h3 className="font-semibold text-gray-900 group-hover:text-indigo-600 transition-colors">
                        {template.name}
                      </h3>
                      <p className="text-sm text-gray-500">{template.category}</p>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    {template.isPopular && (
                      <span className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded-full font-medium flex items-center gap-1">
                        <Star className="w-3 h-3" />
                        Popular
                      </span>
                    )}
                    {template.isPremium && (
                      <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded-full font-medium flex items-center gap-1">
                        <Sparkles className="w-3 h-3" />
                        Pro
                      </span>
                    )}
                  </div>
                </div>

                <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                  {template.description}
                </p>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setPreviewTemplate(template)}
                    className="flex-1 flex items-center justify-center gap-2 py-2 px-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors text-sm font-medium"
                  >
                    <Eye className="w-4 h-4" />
                    Preview
                  </button>
                  <button
                    onClick={() => handleUseTemplate(template)}
                    className="flex-1 flex items-center justify-center gap-2 py-2 px-3 bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg transition-colors text-sm font-medium"
                  >
                    <ArrowRight className="w-4 h-4" />
                    Use
                  </button>
                </div>
              </div>
            ))}
          </div>

          {filteredTemplates.length === 0 && (
            <div className="text-center py-12">
              <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Bookmark className="w-12 h-12 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No templates found</h3>
              <p className="text-gray-600">Try adjusting your search or category filter</p>
            </div>
          )}
        </div>

        {/* Template Preview Modal */}
        {previewTemplate && (
          <div className="absolute inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4">
            <div className="bg-white rounded-xl max-w-2xl w-full max-h-[80vh] overflow-y-auto">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="text-2xl">{previewTemplate.icon}</div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{previewTemplate.name}</h3>
                      <p className="text-gray-600">{previewTemplate.description}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setPreviewTemplate(null)}
                    className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    ✕
                  </button>
                </div>
              </div>
              
              <div className="p-6">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Content Preview</h4>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <pre className="text-sm text-gray-700 whitespace-pre-wrap break-words font-mono">
                        {previewTemplate.data.content}
                      </pre>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Type:</span>
                      <span className="ml-2 font-medium uppercase">{previewTemplate.data.qr_type}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Category:</span>
                      <span className="ml-2 font-medium capitalize">{previewTemplate.data.category}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Style:</span>
                      <span className="ml-2 font-medium capitalize">{previewTemplate.data.qr_style}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Color:</span>
                      <div className="inline-flex items-center gap-2 ml-2">
                        <div 
                          className="w-4 h-4 rounded-full border"
                          style={{ backgroundColor: previewTemplate.data.custom_color }}
                        ></div>
                        <span className="font-medium">{previewTemplate.data.custom_color}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex gap-3 pt-4">
                    <button
                      onClick={() => setPreviewTemplate(null)}
                      className="flex-1 py-2 px-4 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors font-medium"
                    >
                      Close
                    </button>
                    <button
                      onClick={() => handleUseTemplate(previewTemplate)}
                      className="flex-1 py-2 px-4 bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg transition-colors font-medium"
                    >
                      Use This Template
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
