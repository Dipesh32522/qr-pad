import { useState } from 'react';
import { X, Download, Share2, Copy, Check, Shield, Clock, MapPin, BarChart3 } from 'lucide-react';
import { QRCodeType, CategoryColors, CategoryIcons } from '@/shared/types';

interface QRModalProps {
  qrCode: QRCodeType;
  onClose: () => void;
  onScan: (id: number) => void;
}

export default function QRModal({ qrCode, onClose, onScan }: QRModalProps) {
  const [copied, setCopied] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [passwordError, setPasswordError] = useState('');

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(qrCode.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const handleDownload = () => {
    if (qrCode.qr_data_url) {
      const link = document.createElement('a');
      link.href = qrCode.qr_data_url;
      link.download = `${qrCode.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_qr.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleShare = async () => {
    if (navigator.share && qrCode.qr_data_url) {
      try {
        const response = await fetch(qrCode.qr_data_url);
        const blob = await response.blob();
        const file = new File([blob], `${qrCode.title}_qr.png`, { type: 'image/png' });
        
        await navigator.share({
          title: qrCode.title,
          text: `Check out this QR code: ${qrCode.title}`,
          files: [file]
        });
      } catch (err) {
        console.error('Error sharing:', err);
        handleCopy();
      }
    } else {
      handleCopy();
    }
  };

  const handlePasswordSubmit = () => {
    if (!passwordInput) {
      setPasswordError('Password is required');
      return;
    }
    
    // Simple password check (in production, this would be validated server-side)
    const expectedHash = qrCode.password_hash;
    const inputHash = btoa(passwordInput);
    
    if (inputHash !== expectedHash) {
      setPasswordError('Incorrect password');
      return;
    }
    
    setPasswordError('');
    setShowPassword(false);
    onScan(qrCode.id);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const isExpired = qrCode.expires_at && new Date(qrCode.expires_at) < new Date();
  const categoryColor = qrCode.category ? CategoryColors[qrCode.category] : CategoryColors.other;
  const categoryIcon = qrCode.category ? CategoryIcons[qrCode.category] : CategoryIcons.other;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className={`w-12 h-12 ${categoryColor} rounded-xl flex items-center justify-center text-white text-xl`}>
                {categoryIcon}
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">{qrCode.title}</h2>
                <p className="text-gray-600 capitalize">{qrCode.qr_type} • {qrCode.category}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="p-6">
          {/* Expiry Warning */}
          {isExpired && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl">
              <div className="flex items-center gap-2 text-red-700">
                <Clock className="w-5 h-5" />
                <p className="font-medium">This QR code has expired</p>
              </div>
            </div>
          )}

          {/* Password Protection */}
          {qrCode.is_password_protected && !showPassword && (
            <div className="mb-6 p-6 bg-yellow-50 border border-yellow-200 rounded-xl">
              <div className="flex items-center gap-3 mb-4">
                <Shield className="w-6 h-6 text-yellow-600" />
                <h3 className="text-lg font-semibold text-yellow-800">Password Protected</h3>
              </div>
              <p className="text-yellow-700 mb-4">This QR code is password protected. Enter the password to view its content.</p>
              <div className="space-y-3">
                <input
                  type="password"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="Enter password"
                  className="w-full px-4 py-3 border border-yellow-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                  onKeyPress={(e) => e.key === 'Enter' && handlePasswordSubmit()}
                />
                {passwordError && (
                  <p className="text-red-600 text-sm">{passwordError}</p>
                )}
                <button
                  onClick={handlePasswordSubmit}
                  className="px-6 py-2 bg-yellow-600 text-white rounded-lg font-medium hover:bg-yellow-700 transition-colors"
                >
                  Unlock
                </button>
              </div>
            </div>
          )}

          {/* QR Code Display */}
          {(!qrCode.is_password_protected || showPassword) && !isExpired && (
            <div className="space-y-6">
              {/* QR Image */}
              <div className="flex justify-center">
                {qrCode.qr_data_url ? (
                  <div className="p-4 bg-white border-2 border-gray-200 rounded-2xl shadow-lg">
                    <img
                      src={qrCode.qr_data_url}
                      alt={qrCode.title}
                      className="w-64 h-64 rounded-xl"
                    />
                  </div>
                ) : (
                  <div className="w-64 h-64 bg-gray-100 rounded-xl flex items-center justify-center">
                    <span className="text-gray-400">No QR Code</span>
                  </div>
                )}
              </div>

              {/* Content */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Content</h3>
                <div className="bg-gray-50 rounded-xl p-4">
                  <pre className="text-sm text-gray-700 whitespace-pre-wrap break-words font-mono">
                    {qrCode.content}
                  </pre>
                </div>
              </div>

              {/* Actions */}
              <div className="grid grid-cols-3 gap-3">
                <button
                  onClick={handleCopy}
                  className="flex items-center justify-center gap-2 py-3 px-4 bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors font-medium"
                >
                  {copied ? <Check className="w-5 h-5 text-green-600" /> : <Copy className="w-5 h-5" />}
                  {copied ? 'Copied!' : 'Copy'}
                </button>
                <button
                  onClick={handleShare}
                  className="flex items-center justify-center gap-2 py-3 px-4 bg-blue-50 hover:bg-blue-100 text-blue-600 rounded-xl transition-colors font-medium"
                >
                  <Share2 className="w-5 h-5" />
                  Share
                </button>
                <button
                  onClick={handleDownload}
                  className="flex items-center justify-center gap-2 py-3 px-4 bg-green-50 hover:bg-green-100 text-green-600 rounded-xl transition-colors font-medium"
                >
                  <Download className="w-5 h-5" />
                  Download
                </button>
              </div>
            </div>
          )}

          {/* Metadata */}
          <div className="mt-8 space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">Details</h3>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-gray-500" />
                <span className="text-gray-600">Scans:</span>
                <span className="font-medium">{qrCode.scan_count}</span>
              </div>
              
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-gray-500" />
                <span className="text-gray-600">Created:</span>
                <span className="font-medium">{formatDate(qrCode.created_at)}</span>
              </div>

              {qrCode.expires_at && (
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-orange-500" />
                  <span className="text-gray-600">Expires:</span>
                  <span className="font-medium text-orange-600">{formatDate(qrCode.expires_at)}</span>
                </div>
              )}

              {qrCode.geo_latitude && qrCode.geo_longitude && (
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-green-500" />
                  <span className="text-gray-600">Geo-locked</span>
                </div>
              )}
            </div>

            {/* Features */}
            <div className="flex flex-wrap gap-2">
              {qrCode.is_password_protected && (
                <span className="px-3 py-1 bg-yellow-100 text-yellow-800 text-sm rounded-full font-medium">
                  🔒 Password Protected
                </span>
              )}
              {qrCode.is_dynamic && (
                <span className="px-3 py-1 bg-blue-100 text-blue-800 text-sm rounded-full font-medium">
                  🔄 Dynamic Content
                </span>
              )}
              {qrCode.geo_latitude && (
                <span className="px-3 py-1 bg-green-100 text-green-800 text-sm rounded-full font-medium">
                  📍 Geo-fenced
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
