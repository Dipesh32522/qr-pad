import { useState } from 'react';
import { X, ChevronLeft, ChevronRight, Play, QrCode, Scan, Palette, FolderPlus, Grid3x3, Search } from 'lucide-react';

interface UserGuideModalProps {
  onClose: () => void;
}

const guideSteps = [
  {
    id: 1,
    title: "Welcome to QR Pad",
    icon: QrCode,
    content: {
      heading: "Your Ultimate QR Code Solution",
      description: "QR Pad is a comprehensive QR code generator and scanner that lets you create, customize, and manage QR codes with ease.",
      features: [
        "Generate QR codes for text, URLs, email, phone, WiFi, and more",
        "Customize colors, styles, and add logos",
        "Scan QR codes with your camera or upload images",
        "Organize with custom categories",
        "Track scan statistics"
      ],
      image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=400&h=300&fit=crop&crop=center"
    }
  },
  {
    id: 2,
    title: "Creating Your First QR Code",
    icon: QrCode,
    content: {
      heading: "Generate QR Codes in Seconds",
      description: "Follow these simple steps to create your first QR code:",
      steps: [
        {
          number: "1",
          title: "Enter a Title",
          description: "Give your QR code a descriptive name for easy identification"
        },
        {
          number: "2", 
          title: "Choose QR Type",
          description: "Select from Text, URL, Email, Phone, SMS, WiFi, or Contact"
        },
        {
          number: "3",
          title: "Add Content",
          description: "Enter the content you want to encode in the QR code"
        },
        {
          number: "4",
          title: "Select Category",
          description: "Choose a category to organize your QR codes"
        },
        {
          number: "5",
          title: "Generate",
          description: "Click 'Generate QR Code' to create your custom QR code"
        }
      ],
      image: "https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=400&h=300&fit=crop&crop=center"
    }
  },
  {
    id: 3,
    title: "Advanced Customization",
    icon: Palette,
    content: {
      heading: "Make Your QR Codes Stand Out",
      description: "Customize your QR codes with advanced styling options:",
      features: [
        "Custom foreground and background colors",
        "Multiple QR code styles (Square, Circle, Rounded)",
        "Corner style customization",
        "Border options (None, Thin, Thick)",
        "Logo embedding from URL",
        "Live preview of customizations",
        "Password protection",
        "Expiry date settings"
      ],
      tips: [
        "Use contrasting colors for better scanability",
        "Keep logos small and centered",
        "Test your QR codes before sharing"
      ],
      image: "https://images.unsplash.com/photo-1609205248268-2aaa9b281d74?w=400&h=300&fit=crop&crop=center"
    }
  },
  {
    id: 4,
    title: "Custom Categories",
    icon: FolderPlus,
    content: {
      heading: "Organize with Custom Categories",
      description: "Create personalized categories beyond the default options:",
      steps: [
        {
          number: "1",
          title: "Click 'Add Custom Category'",
          description: "Find the button in the category selection area"
        },
        {
          number: "2",
          title: "Choose Name & Icon",
          description: "Enter a category name and select an emoji icon"
        },
        {
          number: "3",
          title: "Pick a Color",
          description: "Choose from predefined colors or use a custom color"
        },
        {
          number: "4",
          title: "Preview & Create",
          description: "See how your category looks and create it"
        }
      ],
      features: [
        "Unlimited custom categories",
        "Emoji icon selection",
        "Custom color options",
        "Easy category management",
        "Delete unwanted categories"
      ],
      image: "https://images.unsplash.com/photo-1606092195730-5d7b9af1efc5?w=400&h=300&fit=crop&crop=center"
    }
  },
  {
    id: 5,
    title: "Scanning QR Codes",
    icon: Scan,
    content: {
      heading: "Scan QR Codes Instantly",
      description: "Use the built-in scanner to read any QR code:",
      methods: [
        {
          title: "Camera Scan",
          description: "Use your device camera to scan QR codes in real-time",
          steps: ["Click 'Scan' button", "Allow camera access", "Point camera at QR code", "QR code detected automatically"]
        },
        {
          title: "Upload Image",
          description: "Upload an image containing a QR code from your device",
          steps: ["Click 'Upload Image'", "Select image file", "QR code extracted automatically"]
        }
      ],
      features: [
        "Automatic QR type detection",
        "Smart content handling (opens URLs, dials numbers, etc.)",
        "Detailed content preview",
        "Copy content to clipboard",
        "Share QR code content"
      ],
      image: "https://images.unsplash.com/photo-1604881991405-7c6e7d9f1f5d?w=400&h=300&fit=crop&crop=center"
    }
  },
  {
    id: 6,
    title: "Managing Your QR Library",
    icon: Grid3x3,
    content: {
      heading: "Organize and Track Your QR Codes",
      description: "Efficiently manage your QR code collection:",
      features: [
        "View all QR codes in grid or list format",
        "Search by title or content",
        "Filter by category (default + custom)",
        "Sort by creation date, scan count, or name",
        "Track scan statistics",
        "Quick actions: Copy, Share, Download, Delete"
      ],
      actions: [
        {
          title: "View Details",
          description: "Click the eye icon to see full QR code details and analytics"
        },
        {
          title: "Download QR Code",
          description: "Save QR code as PNG image to your device"
        },
        {
          title: "Share QR Code",
          description: "Share QR code image or content with others"
        },
        {
          title: "Copy Content",
          description: "Copy the QR code content to clipboard"
        }
      ],
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop&crop=center"
    }
  },
  {
    id: 7,
    title: "Tips & Best Practices",
    icon: Search,
    content: {
      heading: "Get the Most Out of QR Pad",
      description: "Follow these tips for optimal QR code creation and usage:",
      tips: [
        {
          category: "Design Tips",
          items: [
            "Use high contrast colors (dark on light background)",
            "Avoid overly complex backgrounds",
            "Keep logos small (max 20% of QR code size)",
            "Test QR codes at the intended scan distance"
          ]
        },
        {
          category: "Content Tips",
          items: [
            "Keep URLs short for cleaner QR codes",
            "Include country code for phone numbers (+1234567890)",
            "Use proper WiFi format: WIFI:T:WPA;S:NetworkName;P:Password;;",
            "Test all links and content before sharing"
          ]
        },
        {
          category: "Security Tips",
          items: [
            "Use password protection for sensitive content",
            "Set expiry dates for temporary QR codes",
            "Regularly review and clean up old QR codes",
            "Don't include sensitive information in public QR codes"
          ]
        },
        {
          category: "Organization Tips",
          items: [
            "Use descriptive titles for easy identification",
            "Create custom categories for better organization",
            "Tag related QR codes with similar categories",
            "Monitor scan statistics to track usage"
          ]
        }
      ],
      image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400&h=300&fit=crop&crop=center"
    }
  }
];

export default function UserGuideModal({ onClose }: UserGuideModalProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  const nextStep = () => {
    if (currentStep < guideSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const goToStep = (stepIndex: number) => {
    setCurrentStep(stepIndex);
  };

  const startAutoPlay = () => {
    if (isPlaying) {
      setIsPlaying(false);
      return;
    }
    
    setIsPlaying(true);
    const interval = setInterval(() => {
      setCurrentStep(prev => {
        if (prev >= guideSteps.length - 1) {
          setIsPlaying(false);
          clearInterval(interval);
          return prev;
        }
        return prev + 1;
      });
    }, 4000);
  };

  const currentStepData = guideSteps[currentStep];
  const Icon = currentStepData.icon;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 bg-gradient-to-r from-blue-500 to-purple-600 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
                <Icon className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">QR Pad User Guide</h2>
                <p className="text-blue-100">Step-by-step tutorial to master QR Pad</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-blue-100 hover:text-white hover:bg-white hover:bg-opacity-20 rounded-lg transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Progress */}
          <div className="mt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-blue-100">
                Step {currentStep + 1} of {guideSteps.length}
              </span>
              <button
                onClick={startAutoPlay}
                className="flex items-center gap-2 px-3 py-1 bg-white bg-opacity-20 rounded-lg text-sm hover:bg-opacity-30 transition-colors"
              >
                <Play className="w-4 h-4" />
                {isPlaying ? 'Stop Auto Play' : 'Auto Play'}
              </button>
            </div>
            <div className="w-full bg-blue-400 bg-opacity-30 rounded-full h-2">
              <div 
                className="bg-white h-2 rounded-full transition-all duration-300"
                style={{ width: `${((currentStep + 1) / guideSteps.length) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="flex h-[calc(90vh-200px)]">
          {/* Sidebar */}
          <div className="w-64 border-r border-gray-200 p-4 overflow-y-auto">
            <div className="space-y-2">
              {guideSteps.map((step, index) => {
                const StepIcon = step.icon;
                return (
                  <button
                    key={step.id}
                    onClick={() => goToStep(index)}
                    className={`w-full p-3 text-left rounded-xl transition-all ${
                      index === currentStep
                        ? 'bg-blue-50 border-2 border-blue-500 text-blue-600'
                        : 'border-2 border-transparent hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                        index === currentStep ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-600'
                      }`}>
                        <StepIcon className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-medium text-sm">{step.title}</div>
                        <div className="text-xs text-gray-500">Step {index + 1}</div>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 p-6 overflow-y-auto">
            <div className="max-w-2xl">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                {currentStepData.content.heading}
              </h3>
              
              <p className="text-gray-600 mb-6">
                {currentStepData.content.description}
              </p>

              {/* Image */}
              {currentStepData.content.image && (
                <div className="mb-6">
                  <img
                    src={currentStepData.content.image}
                    alt={currentStepData.title}
                    className="w-full h-48 object-cover rounded-xl border border-gray-200"
                  />
                </div>
              )}

              {/* Features */}
              {currentStepData.content.features && (
                <div className="mb-6">
                  <h4 className="font-semibold text-gray-900 mb-3">Key Features:</h4>
                  <ul className="space-y-2">
                    {currentStepData.content.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Steps */}
              {currentStepData.content.steps && (
                <div className="mb-6">
                  <h4 className="font-semibold text-gray-900 mb-4">Step-by-Step Instructions:</h4>
                  <div className="space-y-4">
                    {currentStepData.content.steps.map((step, index) => (
                      <div key={index} className="flex gap-4">
                        <div className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center font-semibold text-sm flex-shrink-0">
                          {step.number}
                        </div>
                        <div>
                          <h5 className="font-medium text-gray-900">{step.title}</h5>
                          <p className="text-gray-600 text-sm">{step.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Methods */}
              {currentStepData.content.methods && (
                <div className="mb-6">
                  <h4 className="font-semibold text-gray-900 mb-4">Scanning Methods:</h4>
                  <div className="grid gap-4">
                    {currentStepData.content.methods.map((method, index) => (
                      <div key={index} className="p-4 border border-gray-200 rounded-xl">
                        <h5 className="font-medium text-gray-900 mb-2">{method.title}</h5>
                        <p className="text-gray-600 text-sm mb-3">{method.description}</p>
                        <ol className="space-y-1">
                          {method.steps.map((step, stepIndex) => (
                            <li key={stepIndex} className="text-sm text-gray-600">
                              {stepIndex + 1}. {step}
                            </li>
                          ))}
                        </ol>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Actions */}
              {currentStepData.content.actions && (
                <div className="mb-6">
                  <h4 className="font-semibold text-gray-900 mb-4">Available Actions:</h4>
                  <div className="grid gap-3">
                    {currentStepData.content.actions.map((action, index) => (
                      <div key={index} className="p-3 bg-gray-50 rounded-lg">
                        <h5 className="font-medium text-gray-900 text-sm">{action.title}</h5>
                        <p className="text-gray-600 text-xs">{action.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tips */}
              {currentStepData.content.tips && (
                <div className="mb-6">
                  {Array.isArray(currentStepData.content.tips) && typeof currentStepData.content.tips[0] === 'string' ? (
                    <>
                      <h4 className="font-semibold text-gray-900 mb-3">Pro Tips:</h4>
                      <ul className="space-y-2">
                        {(currentStepData.content.tips as string[]).map((tip: string, index: number) => (
                          <li key={index} className="flex items-start gap-3">
                            <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2 flex-shrink-0" />
                            <span className="text-gray-700 text-sm">{tip}</span>
                          </li>
                        ))}
                      </ul>
                    </>
                  ) : (
                    <div className="space-y-6">
                      {(currentStepData.content.tips as any[]).map((tipCategory: any, index: number) => (
                        <div key={index}>
                          <h4 className="font-semibold text-gray-900 mb-3">{tipCategory.category}:</h4>
                          <ul className="space-y-2">
                            {tipCategory.items.map((tip: string, tipIndex: number) => (
                              <li key={tipIndex} className="flex items-start gap-3">
                                <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2 flex-shrink-0" />
                                <span className="text-gray-700 text-sm">{tip}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-gray-200 bg-gray-50">
          <div className="flex items-center justify-between">
            <button
              onClick={prevStep}
              disabled={currentStep === 0}
              className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed text-gray-700 rounded-lg font-medium transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
              Previous
            </button>

            <div className="flex items-center gap-2">
              {guideSteps.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToStep(index)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === currentStep ? 'bg-blue-500' : 'bg-gray-300'
                  }`}
                />
              ))}
            </div>

            {currentStep === guideSteps.length - 1 ? (
              <button
                onClick={onClose}
                className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg font-medium hover:from-blue-600 hover:to-purple-700 transition-all"
              >
                Get Started
              </button>
            ) : (
              <button
                onClick={nextStep}
                className="flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg font-medium transition-colors"
              >
                Next
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
