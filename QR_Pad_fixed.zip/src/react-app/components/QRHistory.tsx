import { useState, useEffect } from 'react';
import { History, RotateCcw, Star, Trash2, Download, Copy, Check, Clock, TrendingUp } from 'lucide-react';
import { QRCodeType } from '@/shared/types';

interface QRHistoryProps {
  qrCodes: QRCodeType[];
  onRestore: (qrCode: QRCodeType) => void;
  onDelete: (id: number) => void;
  onClose: () => void;
}

interface HistoryItem extends QRCodeType {
  isDeleted?: boolean;
  deletedAt?: string;
  version?: number;
  changes?: string[];
}

export default function QRHistory({ qrCodes, onRestore, onDelete, onClose }: QRHistoryProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'date' | 'scans' | 'name'>('date');
  const [timeframe, setTimeframe] = useState<'today' | 'week' | 'month' | 'all'>('all');
  const [copied, setCopied] = useState<string | null>(null);

  // Mock history data - in real app, this would come from backend
  const [historyItems, setHistoryItems] = useState<HistoryItem[]>([]);

  useEffect(() => {
    // Generate mock history data based on existing QR codes
    const mockHistory: HistoryItem[] = [];
    
    qrCodes.forEach(qr => {
      // Add current version
      mockHistory.push({
        ...qr,
        version: 1,
        changes: []
      });

      // Add some mock previous versions
      if (Math.random() > 0.7) {
        const prevDate = new Date(qr.created_at);
        prevDate.setHours(prevDate.getHours() - Math.floor(Math.random() * 48));
        
        mockHistory.push({
          ...qr,
          id: qr.id + 1000,
          title: qr.title + ' (v0.9)',
          scan_count: Math.max(0, qr.scan_count - Math.floor(Math.random() * 10)),
          created_at: prevDate.toISOString(),
          version: 0.9,
          changes: ['Title updated', 'Content modified']
        });
      }
    });

    // Add some mock deleted items
    const deletedItems: HistoryItem[] = [
      {
        id: 9001,
        title: 'Old Company Website',
        content: 'https://oldcompany.com',
        qr_type: 'url',
        category: 'business',
        scan_count: 45,
        is_password_protected: false,
        is_dynamic: false,
        custom_color: '#000000',
        created_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        updated_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        isDeleted: true,
        deletedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        version: 1,
        changes: []
      },
      {
        id: 9002,
        title: 'Event Registration',
        content: 'https://eventbrite.com/old-event',
        qr_type: 'url',
        category: 'events',
        scan_count: 23,
        is_password_protected: false,
        is_dynamic: false,
        custom_color: '#000000',
        created_at: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
        updated_at: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
        isDeleted: true,
        deletedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        version: 1,
        changes: []
      }
    ];

    mockHistory.push(...deletedItems);
    setHistoryItems(mockHistory);
  }, [qrCodes]);

  const filteredItems = historyItems
    .filter(item => {
      const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           item.content.toLowerCase().includes(searchTerm.toLowerCase());
      
      if (!matchesSearch) return false;

      const itemDate = new Date(item.deletedAt || item.created_at);
      const now = new Date();
      
      switch (timeframe) {
        case 'today':
          return itemDate.toDateString() === now.toDateString();
        case 'week':
          const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
          return itemDate >= weekAgo;
        case 'month':
          const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
          return itemDate >= monthAgo;
        default:
          return true;
      }
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'date':
          return new Date(b.deletedAt || b.created_at).getTime() - new Date(a.deletedAt || a.created_at).getTime();
        case 'scans':
          return b.scan_count - a.scan_count;
        case 'name':
          return a.title.localeCompare(b.title);
        default:
          return 0;
      }
    });

  const handleCopy = async (content: string, id: string) => {
    try {
      await navigator.clipboard.writeText(content);
      setCopied(id);
      setTimeout(() => setCopied(null), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const handleRestore = (item: HistoryItem) => {
    if (confirm(`Restore "${item.title}"? This will create a new QR code.`)) {
      onRestore(item);
    }
  };

  const exportHistory = () => {
    const csvContent = [
      'QR Code History Report',
      `Generated: ${new Date().toLocaleDateString()}`,
      '',
      'Title,Content,Type,Category,Scans,Created,Status',
      ...filteredItems.map(item => 
        `"${item.title}","${item.content}","${item.qr_type}","${item.category || 'other'}","${item.scan_count}","${new Date(item.created_at).toLocaleDateString()}","${item.isDeleted ? 'Deleted' : 'Active'}"`
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `qr_history_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const stats = {
    total: historyItems.length,
    active: historyItems.filter(item => !item.isDeleted).length,
    deleted: historyItems.filter(item => item.isDeleted).length,
    totalScans: historyItems.reduce((sum, item) => sum + item.scan_count, 0)
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-6xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 bg-gradient-to-r from-amber-500 to-orange-600 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
                <History className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">QR Code History</h2>
                <p className="text-amber-100">View and manage your QR code history</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={exportHistory}
                className="flex items-center gap-2 px-4 py-2 bg-white bg-opacity-20 rounded-lg hover:bg-opacity-30 transition-colors"
              >
                <Download className="w-4 h-4" />
                Export
              </button>
              <button
                onClick={onClose}
                className="p-2 text-amber-100 hover:text-white hover:bg-white hover:bg-opacity-20 rounded-lg transition-colors"
              >
                ✕
              </button>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="p-6 border-b border-gray-200 bg-gray-50">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
              <div className="text-sm text-gray-600">Total Items</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{stats.active}</div>
              <div className="text-sm text-gray-600">Active QRs</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">{stats.deleted}</div>
              <div className="text-sm text-gray-600">Deleted QRs</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{stats.totalScans.toLocaleString()}</div>
              <div className="text-sm text-gray-600">Total Scans</div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search history..."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
              />
            </div>
            <div className="flex gap-2">
              <select
                value={timeframe}
                onChange={(e) => setTimeframe(e.target.value as any)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500"
              >
                <option value="all">All Time</option>
                <option value="today">Today</option>
                <option value="week">Last Week</option>
                <option value="month">Last Month</option>
              </select>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500"
              >
                <option value="date">Date</option>
                <option value="scans">Scans</option>
                <option value="name">Name</option>
              </select>
            </div>
          </div>
        </div>

        {/* History List */}
        <div className="overflow-y-auto max-h-[calc(90vh-400px)]">
          {filteredItems.length > 0 ? (
            <div className="p-6">
              <div className="space-y-4">
                {filteredItems.map(item => (
                  <div
                    key={`${item.id}-${item.version}`}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      item.isDeleted
                        ? 'border-red-200 bg-red-50'
                        : 'border-gray-200 bg-white hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className={`font-semibold ${item.isDeleted ? 'text-red-700' : 'text-gray-900'}`}>
                            {item.title}
                          </h3>
                          {item.version && item.version < 1 && (
                            <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full font-medium">
                              v{item.version}
                            </span>
                          )}
                          {item.isDeleted && (
                            <span className="px-2 py-1 bg-red-100 text-red-800 text-xs rounded-full font-medium">
                              Deleted
                            </span>
                          )}
                          {item.scan_count > 50 && (
                            <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full font-medium flex items-center gap-1">
                              <Star className="w-3 h-3" />
                              Popular
                            </span>
                          )}
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600 mb-3">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">Type:</span>
                            <span className="uppercase">{item.qr_type}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <TrendingUp className="w-4 h-4" />
                            <span>{item.scan_count} scans</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Clock className="w-4 h-4" />
                            <span>
                              {item.isDeleted
                                ? `Deleted ${new Date(item.deletedAt!).toLocaleDateString()}`
                                : `Created ${new Date(item.created_at).toLocaleDateString()}`
                              }
                            </span>
                          </div>
                        </div>

                        <div className="bg-gray-50 rounded-lg p-3 mb-3">
                          <p className="text-sm text-gray-700 line-clamp-2 font-mono">
                            {item.content}
                          </p>
                        </div>

                        {item.changes && item.changes.length > 0 && (
                          <div className="mb-3">
                            <div className="text-xs text-gray-500 mb-1">Changes:</div>
                            <div className="flex flex-wrap gap-1">
                              {item.changes.map((change, index) => (
                                <span
                                  key={index}
                                  className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full"
                                >
                                  {change}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-2 ml-4">
                        <button
                          onClick={() => handleCopy(item.content, `${item.id}-${item.version}`)}
                          className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="Copy Content"
                        >
                          {copied === `${item.id}-${item.version}` ? (
                            <Check className="w-4 h-4 text-green-600" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                        </button>
                        
                        {item.isDeleted ? (
                          <button
                            onClick={() => handleRestore(item)}
                            className="p-2 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                            title="Restore QR Code"
                          >
                            <RotateCcw className="w-4 h-4" />
                          </button>
                        ) : (
                          <button
                            onClick={() => onDelete(item.id)}
                            className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            title="Delete QR Code"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="p-12 text-center">
              <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <History className="w-12 h-12 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No history found</h3>
              <p className="text-gray-600">Try adjusting your search or time filter</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
