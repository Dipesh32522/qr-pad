import { useState } from 'react';
import { X, ExternalLink, Copy, Check, Phone, Mail, MapPin, Wifi, User, MessageSquare } from 'lucide-react';

interface QRResultModalProps {
  data: string;
  onClose: () => void;
}

export default function QRResultModal({ data, onClose }: QRResultModalProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(data);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const getQRType = (data: string) => {
    if (data.startsWith('http://') || data.startsWith('https://')) {
      return 'url';
    } else if (data.startsWith('mailto:')) {
      return 'email';
    } else if (data.startsWith('tel:') || data.match(/^\+?[1-9]\d{1,14}$/)) {
      return 'phone';
    } else if (data.startsWith('WIFI:')) {
      return 'wifi';
    } else if (data.startsWith('SMSTO:')) {
      return 'sms';
    } else if (data.startsWith('BEGIN:VCARD')) {
      return 'contact';
    } else if (data.startsWith('geo:') || data.includes('maps.google.com')) {
      return 'location';
    } else {
      return 'text';
    }
  };

  const handleAction = () => {
    const qrType = getQRType(data);
    
    switch (qrType) {
      case 'url':
        window.open(data, '_blank', 'noopener,noreferrer');
        break;
      case 'email':
        window.location.href = data;
        break;
      case 'phone':
        window.location.href = data.startsWith('tel:') ? data : `tel:${data}`;
        break;
      case 'sms':
        window.location.href = data;
        break;
      case 'location':
        if (data.startsWith('geo:')) {
          const coords = data.replace('geo:', '').split(',');
          window.open(`https://maps.google.com/?q=${coords[0]},${coords[1]}`, '_blank');
        } else {
          window.open(data, '_blank');
        }
        break;
      default:
        handleCopy();
        break;
    }
  };

  const parseWifiData = (wifiString: string) => {
    const parts = wifiString.split(';');
    const wifi: any = {};
    
    parts.forEach(part => {
      if (part.startsWith('T:')) wifi.type = part.substring(2);
      if (part.startsWith('S:')) wifi.ssid = part.substring(2);
      if (part.startsWith('P:')) wifi.password = part.substring(2);
      if (part.startsWith('H:')) wifi.hidden = part.substring(2) === 'true';
    });
    
    return wifi;
  };

  const parseContactData = (vcard: string) => {
    const lines = vcard.split('\n');
    const contact: any = {};
    
    lines.forEach(line => {
      if (line.startsWith('FN:')) contact.name = line.substring(3);
      if (line.startsWith('ORG:')) contact.organization = line.substring(4);
      if (line.startsWith('TEL:')) contact.phone = line.substring(4);
      if (line.startsWith('EMAIL:')) contact.email = line.substring(6);
      if (line.startsWith('URL:')) contact.website = line.substring(4);
    });
    
    return contact;
  };

  const parseSmsData = (smsString: string) => {
    const match = smsString.match(/SMSTO:([^:]+):(.+)/);
    return match ? { phone: match[1], message: match[2] } : null;
  };

  const qrType = getQRType(data);
  
  const getIcon = () => {
    switch (qrType) {
      case 'url': return <ExternalLink className="w-6 h-6" />;
      case 'email': return <Mail className="w-6 h-6" />;
      case 'phone': return <Phone className="w-6 h-6" />;
      case 'wifi': return <Wifi className="w-6 h-6" />;
      case 'contact': return <User className="w-6 h-6" />;
      case 'sms': return <MessageSquare className="w-6 h-6" />;
      case 'location': return <MapPin className="w-6 h-6" />;
      default: return <Copy className="w-6 h-6" />;
    }
  };

  const getTitle = () => {
    switch (qrType) {
      case 'url': return 'Website Link';
      case 'email': return 'Email Address';
      case 'phone': return 'Phone Number';
      case 'wifi': return 'WiFi Network';
      case 'contact': return 'Contact Card';
      case 'sms': return 'SMS Message';
      case 'location': return 'Location';
      default: return 'Text Content';
    }
  };

  const getActionText = () => {
    switch (qrType) {
      case 'url': return 'Open Website';
      case 'email': return 'Send Email';
      case 'phone': return 'Call Number';
      case 'sms': return 'Send SMS';
      case 'location': return 'View Location';
      default: return 'Copy Text';
    }
  };

  const renderContent = () => {
    switch (qrType) {
      case 'wifi':
        const wifi = parseWifiData(data);
        return (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-600">Network:</span>
                <div className="font-medium">{wifi.ssid}</div>
              </div>
              <div>
                <span className="text-gray-600">Security:</span>
                <div className="font-medium">{wifi.type || 'Open'}</div>
              </div>
              {wifi.password && (
                <div className="col-span-2">
                  <span className="text-gray-600">Password:</span>
                  <div className="font-medium font-mono bg-gray-100 p-2 rounded">{wifi.password}</div>
                </div>
              )}
            </div>
          </div>
        );
      
      case 'contact':
        const contact = parseContactData(data);
        return (
          <div className="space-y-3">
            <div className="grid gap-3 text-sm">
              {contact.name && (
                <div>
                  <span className="text-gray-600">Name:</span>
                  <div className="font-medium">{contact.name}</div>
                </div>
              )}
              {contact.organization && (
                <div>
                  <span className="text-gray-600">Organization:</span>
                  <div className="font-medium">{contact.organization}</div>
                </div>
              )}
              {contact.phone && (
                <div>
                  <span className="text-gray-600">Phone:</span>
                  <div className="font-medium">{contact.phone}</div>
                </div>
              )}
              {contact.email && (
                <div>
                  <span className="text-gray-600">Email:</span>
                  <div className="font-medium">{contact.email}</div>
                </div>
              )}
              {contact.website && (
                <div>
                  <span className="text-gray-600">Website:</span>
                  <div className="font-medium">{contact.website}</div>
                </div>
              )}
            </div>
          </div>
        );
      
      case 'sms':
        const sms = parseSmsData(data);
        return sms ? (
          <div className="space-y-3">
            <div>
              <span className="text-gray-600">To:</span>
              <div className="font-medium">{sms.phone}</div>
            </div>
            <div>
              <span className="text-gray-600">Message:</span>
              <div className="font-medium bg-gray-100 p-3 rounded-lg">{sms.message}</div>
            </div>
          </div>
        ) : (
          <div className="bg-gray-100 p-4 rounded-lg">
            <pre className="text-sm text-gray-700 whitespace-pre-wrap break-words font-mono">{data}</pre>
          </div>
        );
      
      default:
        return (
          <div className="bg-gray-100 p-4 rounded-lg">
            <pre className="text-sm text-gray-700 whitespace-pre-wrap break-words font-mono">{data}</pre>
          </div>
        );
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-blue-600 rounded-xl flex items-center justify-center text-white">
                {getIcon()}
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900">{getTitle()}</h2>
                <p className="text-gray-600">Scanned successfully</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="p-6">
          {/* Content */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Content</h3>
            {renderContent()}
          </div>

          {/* Actions */}
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={handleAction}
              className="flex items-center justify-center gap-2 py-3 px-4 bg-gradient-to-r from-green-500 to-blue-600 text-white rounded-xl font-medium hover:from-green-600 hover:to-blue-700 transition-all"
            >
              {getIcon()}
              {getActionText()}
            </button>
            <button
              onClick={handleCopy}
              className="flex items-center justify-center gap-2 py-3 px-4 bg-gray-100 hover:bg-gray-200 rounded-xl font-medium transition-colors"
            >
              {copied ? <Check className="w-5 h-5 text-green-600" /> : <Copy className="w-5 h-5" />}
              {copied ? 'Copied!' : 'Copy'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
