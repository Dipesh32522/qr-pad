import { useState } from 'react';
import { Search, Filter, Grid3x3, List, SortDesc, History } from 'lucide-react';
import { QRCodeType, QRCategory, CategoryColors, CategoryIcons } from '@/shared/types';
import QRCard from './QRCard';
import { useCustomCategories } from '@/react-app/hooks/useCustomCategories';

interface QRLibraryProps {
  qrCodes: QRCodeType[];
  onDelete: (id: number) => void;
  onView: (qrCode: QRCodeType) => void;
  isLoading: boolean;
  onShowHistory?: () => void;
}

export default function QRLibrary({ qrCodes, onDelete, onView, isLoading, onShowHistory }: QRLibraryProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<QRCategory | 'all' | string>('all');
  const [sortBy, setSortBy] = useState<'created_at' | 'scan_count' | 'title'>('created_at');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const { customCategories } = useCustomCategories();

  const categories: { value: QRCategory | 'all'; label: string }[] = [
    { value: 'all', label: 'All' },
    { value: 'personal', label: 'Personal' },
    { value: 'business', label: 'Business' },
    { value: 'shopping', label: 'Shopping' },
    { value: 'study', label: 'Study' },
    { value: 'travel', label: 'Travel' },
    { value: 'events', label: 'Events' },
    { value: 'social', label: 'Social' },
    { value: 'other', label: 'Other' }
  ];

  const filteredAndSortedQRCodes = qrCodes
    .filter(qr => {
      const matchesSearch = qr.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           qr.content.toLowerCase().includes(searchTerm.toLowerCase());
      
      let matchesCategory = false;
      if (selectedCategory === 'all') {
        matchesCategory = true;
      } else if (selectedCategory.startsWith('custom_')) {
        const customCategoryId = parseInt(selectedCategory.replace('custom_', ''));
        matchesCategory = qr.custom_category_id === customCategoryId;
      } else {
        matchesCategory = qr.category === selectedCategory;
      }
      
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'created_at':
          return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
        case 'scan_count':
          return b.scan_count - a.scan_count;
        case 'title':
          return a.title.localeCompare(b.title);
        default:
          return 0;
      }
    });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="text-center py-12">
          <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your QR codes...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">QR Library</h2>
          <p className="text-gray-600">
            {filteredAndSortedQRCodes.length} of {qrCodes.length} QR codes
          </p>
        </div>

        <div className="flex items-center gap-2">
          {onShowHistory && (
            <button
              onClick={onShowHistory}
              className="flex items-center gap-2 px-3 py-2 bg-amber-50 hover:bg-amber-100 text-amber-600 rounded-lg transition-colors"
              title="View History"
            >
              <History className="w-4 h-4" />
              <span className="hidden sm:inline">History</span>
            </button>
          )}
          <button
            onClick={() => setViewMode('grid')}
            className={`p-2 rounded-lg transition-colors ${
              viewMode === 'grid'
                ? 'bg-blue-100 text-blue-600'
                : 'text-gray-400 hover:text-gray-600'
            }`}
          >
            <Grid3x3 className="w-5 h-5" />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`p-2 rounded-lg transition-colors ${
              viewMode === 'list'
                ? 'bg-blue-100 text-blue-600'
                : 'text-gray-400 hover:text-gray-600'
            }`}
          >
            <List className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col lg:flex-row gap-4">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search QR codes..."
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
          />
        </div>

        {/* Category Filter */}
        <div className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-gray-400" />
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {categories.map(category => (
              <option key={category.value} value={category.value}>
                {category.label}
              </option>
            ))}
            {customCategories.length > 0 && (
              <optgroup label="Custom Categories">
                {customCategories.map(category => (
                  <option key={`custom_${category.id}`} value={`custom_${category.id}`}>
                    {category.name}
                  </option>
                ))}
              </optgroup>
            )}
          </select>
        </div>

        {/* Sort */}
        <div className="flex items-center gap-2">
          <SortDesc className="w-5 h-5 text-gray-400" />
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'created_at' | 'scan_count' | 'title')}
            className="px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="created_at">Latest</option>
            <option value="scan_count">Most Scanned</option>
            <option value="title">Name A-Z</option>
          </select>
        </div>
      </div>

      {/* Category Stats */}
      {selectedCategory === 'all' && qrCodes.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
          {categories.slice(1).map(category => {
            const count = qrCodes.filter(qr => qr.category === category.value).length;
            if (count === 0) return null;
            
            const categoryColor = CategoryColors[category.value as QRCategory];
            const categoryIcon = CategoryIcons[category.value as QRCategory];
            
            return (
              <button
                key={category.value}
                onClick={() => setSelectedCategory(category.value)}
                className="p-3 bg-white rounded-xl border border-gray-200 hover:border-gray-300 transition-colors text-center"
              >
                <div className={`w-8 h-8 ${categoryColor} rounded-lg flex items-center justify-center text-white mx-auto mb-2`}>
                  <span className="text-sm">{categoryIcon}</span>
                </div>
                <div className="text-xs font-medium text-gray-700">{category.label}</div>
                <div className="text-xs text-gray-500">{count}</div>
              </button>
            );
          })}
          
          {/* Custom Categories */}
          {customCategories.map(category => {
            const count = qrCodes.filter(qr => qr.custom_category_id === category.id).length;
            if (count === 0) return null;
            
            return (
              <button
                key={`custom_${category.id}`}
                onClick={() => setSelectedCategory(`custom_${category.id}`)}
                className="p-3 bg-white rounded-xl border border-gray-200 hover:border-gray-300 transition-colors text-center"
              >
                <div 
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-white mx-auto mb-2"
                  style={{ backgroundColor: category.color }}
                >
                  <span className="text-sm">{category.icon}</span>
                </div>
                <div className="text-xs font-medium text-gray-700">{category.name}</div>
                <div className="text-xs text-gray-500">{count}</div>
              </button>
            );
          })}
        </div>
      )}

      {/* QR Codes Grid/List */}
      {filteredAndSortedQRCodes.length > 0 ? (
        <div className={
          viewMode === 'grid'
            ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6'
            : 'space-y-4'
        }>
          {filteredAndSortedQRCodes.map(qrCode => (
            <QRCard
              key={qrCode.id}
              qrCode={qrCode}
              onDelete={onDelete}
              onView={onView}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Grid3x3 className="w-12 h-12 text-gray-400" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            {searchTerm || selectedCategory !== 'all' ? 'No QR codes found' : 'No QR codes yet'}
          </h3>
          <p className="text-gray-600 mb-6">
            {searchTerm || selectedCategory !== 'all'
              ? 'Try adjusting your search or filters'
              : 'Create your first QR code to get started'
            }
          </p>
          {!searchTerm && selectedCategory === 'all' && (
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl font-medium hover:from-blue-600 hover:to-purple-700 transition-all"
            >
              Create QR Code
            </button>
          )}
        </div>
      )}
    </div>
  );
}
