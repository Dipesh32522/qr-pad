import { useState } from 'react';
import { Download, Share2, Trash2, Eye, BarChart3, Copy, Check } from 'lucide-react';
import { QRCodeType, CategoryColors, CategoryIcons } from '@/shared/types';
import { useCustomCategories } from '@/react-app/hooks/useCustomCategories';

interface QRCardProps {
  qrCode: QRCodeType;
  onDelete: (id: number) => void;
  onView: (qrCode: QRCodeType) => void;
}

export default function QRCard({ qrCode, onDelete, onView }: QRCardProps) {
  const [copied, setCopied] = useState(false);
  const { customCategories } = useCustomCategories();

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(qrCode.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const handleDownload = () => {
    if (qrCode.qr_data_url) {
      const link = document.createElement('a');
      link.href = qrCode.qr_data_url;
      link.download = `${qrCode.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_qr.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleShare = async () => {
    if (navigator.share && qrCode.qr_data_url) {
      try {
        // Convert data URL to blob
        const response = await fetch(qrCode.qr_data_url);
        const blob = await response.blob();
        const file = new File([blob], `${qrCode.title}_qr.png`, { type: 'image/png' });
        
        await navigator.share({
          title: qrCode.title,
          text: `Check out this QR code: ${qrCode.title}`,
          files: [file]
        });
      } catch (err) {
        console.error('Error sharing:', err);
        // Fallback to copying content
        handleCopy();
      }
    } else {
      // Fallback to copying content
      handleCopy();
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const customCategory = qrCode.custom_category_id 
    ? customCategories.find(cat => cat.id === qrCode.custom_category_id)
    : null;
  
  const categoryColor = customCategory 
    ? `bg-[${customCategory.color}]`
    : qrCode.category 
    ? CategoryColors[qrCode.category] 
    : CategoryColors.other;
  
  const categoryIcon = customCategory 
    ? customCategory.icon
    : qrCode.category 
    ? CategoryIcons[qrCode.category] 
    : CategoryIcons.other;
  
  const categoryName = customCategory 
    ? customCategory.name
    : qrCode.category || 'other';

  return (
    <div className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden border border-gray-100 group">
      {/* Header */}
      <div className="p-6 pb-4">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div 
              className={`w-10 h-10 rounded-xl flex items-center justify-center text-white text-lg ${
                customCategory ? '' : categoryColor
              }`}
              style={customCategory ? { backgroundColor: customCategory.color } : {}}
            >
              {categoryIcon}
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 text-lg line-clamp-1">{qrCode.title}</h3>
              <p className="text-sm text-gray-500 capitalize">{qrCode.qr_type} • {categoryName}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <button
              onClick={() => onView(qrCode)}
              className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
              title="View Details"
            >
              <Eye className="w-4 h-4" />
            </button>
            <button
              onClick={() => onDelete(qrCode.id)}
              className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              title="Delete"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* QR Code Preview */}
        <div className="flex justify-center mb-4">
          {qrCode.qr_data_url ? (
            <img
              src={qrCode.qr_data_url}
              alt={qrCode.title}
              className="w-32 h-32 rounded-xl border-2 border-gray-100"
            />
          ) : (
            <div className="w-32 h-32 bg-gray-100 rounded-xl flex items-center justify-center">
              <span className="text-gray-400">No Preview</span>
            </div>
          )}
        </div>

        {/* Content Preview */}
        <div className="bg-gray-50 rounded-xl p-3 mb-4">
          <p className="text-sm text-gray-600 line-clamp-2">{qrCode.content}</p>
        </div>

        {/* Stats */}
        <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
          <div className="flex items-center gap-1">
            <BarChart3 className="w-4 h-4" />
            <span>{qrCode.scan_count} scans</span>
          </div>
          <span>{formatDate(qrCode.created_at)}</span>
        </div>

        {/* Features */}
        <div className="flex gap-2 mb-4">
          {qrCode.is_password_protected && (
            <span className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded-full font-medium">
              🔒 Protected
            </span>
          )}
          {qrCode.expires_at && (
            <span className="px-2 py-1 bg-orange-100 text-orange-800 text-xs rounded-full font-medium">
              ⏰ Expires
            </span>
          )}
          {qrCode.is_dynamic && (
            <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full font-medium">
              🔄 Dynamic
            </span>
          )}
        </div>
      </div>

      {/* Actions */}
      <div className="px-6 pb-6">
        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={handleCopy}
            className="flex items-center justify-center gap-2 py-2 px-3 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors text-sm font-medium"
          >
            {copied ? <Check className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
            {copied ? 'Copied!' : 'Copy'}
          </button>
          <button
            onClick={handleShare}
            className="flex items-center justify-center gap-2 py-2 px-3 bg-blue-50 hover:bg-blue-100 text-blue-600 rounded-lg transition-colors text-sm font-medium"
          >
            <Share2 className="w-4 h-4" />
            Share
          </button>
          <button
            onClick={handleDownload}
            className="flex items-center justify-center gap-2 py-2 px-3 bg-green-50 hover:bg-green-100 text-green-600 rounded-lg transition-colors text-sm font-medium"
          >
            <Download className="w-4 h-4" />
            Save
          </button>
        </div>
      </div>
    </div>
  );
}
