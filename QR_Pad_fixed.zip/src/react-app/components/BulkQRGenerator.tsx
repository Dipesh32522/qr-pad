import { useState } from 'react';
import { Upload, Download, Trash2, Plus, Check, AlertCircle } from 'lucide-react';
import { QRType, QRCategory, CreateQRCodeType } from '@/shared/types';

interface BulkQRGeneratorProps {
  onGenerate: (qrDataList: CreateQRCodeType[]) => Promise<void>;
  isLoading: boolean;
  onClose: () => void;
}

interface BulkItem {
  id: string;
  title: string;
  content: string;
  qr_type: QRType;
  category: QRCategory;
  error?: string;
}

export default function BulkQRGenerator({ onGenerate, isLoading, onClose }: BulkQRGeneratorProps) {
  const [items, setItems] = useState<BulkItem[]>([
    { id: '1', title: '', content: '', qr_type: 'text', category: 'personal' }
  ]);
  const [csvData, setCsvData] = useState('');
  const [showCSVImport, setShowCSVImport] = useState(false);

  const addItem = () => {
    const newItem: BulkItem = {
      id: Date.now().toString(),
      title: '',
      content: '',
      qr_type: 'text',
      category: 'personal'
    };
    setItems([...items, newItem]);
  };

  const removeItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  const updateItem = (id: string, field: keyof BulkItem, value: any) => {
    setItems(items.map(item => 
      item.id === id ? { ...item, [field]: value, error: undefined } : item
    ));
  };

  const validateItems = (): boolean => {
    let isValid = true;
    setItems(items.map(item => {
      let error = '';
      if (!item.title.trim()) error = 'Title is required';
      else if (!item.content.trim()) error = 'Content is required';
      
      if (error) isValid = false;
      return { ...item, error };
    }));
    return isValid;
  };

  const handleGenerate = async () => {
    if (!validateItems()) return;

    const qrDataList: CreateQRCodeType[] = items.map(item => ({
      title: item.title.trim(),
      content: item.content.trim(),
      qr_type: item.qr_type,
      category: item.category,
      is_password_protected: false,
      is_dynamic: false,
      custom_color: '#000000',
      qr_style: 'square',
      background_color: '#FFFFFF',
      has_logo: false,
      border_style: 'none',
      corner_style: 'square'
    }));

    await onGenerate(qrDataList);
  };

  const importCSV = () => {
    try {
      const lines = csvData.trim().split('\n');
      const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
      
      const newItems: BulkItem[] = [];
      
      for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',').map(v => v.trim());
        const item: BulkItem = {
          id: Date.now().toString() + i,
          title: '',
          content: '',
          qr_type: 'text',
          category: 'personal'
        };

        headers.forEach((header, index) => {
          const value = values[index] || '';
          switch (header) {
            case 'title':
              item.title = value;
              break;
            case 'content':
              item.content = value;
              break;
            case 'type':
            case 'qr_type':
              if (['text', 'url', 'email', 'phone', 'sms', 'wifi', 'contact'].includes(value)) {
                item.qr_type = value as QRType;
              }
              break;
            case 'category':
              if (['personal', 'business', 'shopping', 'study', 'travel', 'events', 'social', 'other'].includes(value)) {
                item.category = value as QRCategory;
              }
              break;
          }
        });

        if (item.title && item.content) {
          newItems.push(item);
        }
      }

      setItems(newItems);
      setShowCSVImport(false);
      setCsvData('');
    } catch (error) {
      alert('Error parsing CSV. Please check the format.');
    }
  };

  const downloadTemplate = () => {
    const template = 'title,content,type,category\nExample Website,https://example.com,url,business\nContact Info,John Doe\\nPhone: +1234567890,text,personal';
    const blob = new Blob([template], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'qr_bulk_template.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-6xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 bg-gradient-to-r from-purple-500 to-blue-600 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold">Bulk QR Generator</h2>
              <p className="text-purple-100">Generate multiple QR codes at once</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-purple-100 hover:text-white hover:bg-white hover:bg-opacity-20 rounded-lg transition-colors"
            >
              ✕
            </button>
          </div>
        </div>

        {/* CSV Import Section */}
        {showCSVImport && (
          <div className="p-6 border-b border-gray-200 bg-blue-50">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Import from CSV</h3>
            <div className="space-y-4">
              <textarea
                value={csvData}
                onChange={(e) => setCsvData(e.target.value)}
                placeholder="Paste your CSV data here..."
                rows={6}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <div className="flex items-center justify-between">
                <button
                  onClick={downloadTemplate}
                  className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors"
                >
                  <Download className="w-4 h-4" />
                  Download Template
                </button>
                <div className="flex gap-2">
                  <button
                    onClick={() => setShowCSVImport(false)}
                    className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={importCSV}
                    className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
                  >
                    Import
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">QR Codes ({items.length})</h3>
              <p className="text-gray-600">Add and configure multiple QR codes</p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setShowCSVImport(true)}
                className="flex items-center gap-2 px-4 py-2 bg-blue-50 hover:bg-blue-100 text-blue-600 rounded-lg transition-colors"
              >
                <Upload className="w-4 h-4" />
                Import CSV
              </button>
              <button
                onClick={addItem}
                className="flex items-center gap-2 px-4 py-2 bg-green-50 hover:bg-green-100 text-green-600 rounded-lg transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Item
              </button>
            </div>
          </div>

          <div className="space-y-4 max-h-96 overflow-y-auto">
            {items.map((item, index) => (
              <div key={item.id} className="p-4 border border-gray-200 rounded-xl bg-gray-50">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-medium text-gray-900">QR Code #{index + 1}</h4>
                  <button
                    onClick={() => removeItem(item.id)}
                    className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                    <input
                      type="text"
                      value={item.title}
                      onChange={(e) => updateItem(item.id, 'title', e.target.value)}
                      placeholder="QR Code title"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
                    <select
                      value={item.qr_type}
                      onChange={(e) => updateItem(item.id, 'qr_type', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="text">Text</option>
                      <option value="url">URL</option>
                      <option value="email">Email</option>
                      <option value="phone">Phone</option>
                      <option value="sms">SMS</option>
                      <option value="wifi">WiFi</option>
                      <option value="contact">Contact</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                    <select
                      value={item.category}
                      onChange={(e) => updateItem(item.id, 'category', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="personal">Personal</option>
                      <option value="business">Business</option>
                      <option value="shopping">Shopping</option>
                      <option value="study">Study</option>
                      <option value="travel">Travel</option>
                      <option value="events">Events</option>
                      <option value="social">Social</option>
                      <option value="other">Other</option>
                    </select>
                  </div>

                  <div className="md:col-span-2 lg:col-span-1">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Content</label>
                    <textarea
                      value={item.content}
                      onChange={(e) => updateItem(item.id, 'content', e.target.value)}
                      placeholder="QR Code content"
                      rows={2}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                    />
                  </div>
                </div>

                {item.error && (
                  <div className="mt-3 flex items-center gap-2 text-red-600">
                    <AlertCircle className="w-4 h-4" />
                    <span className="text-sm">{item.error}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-gray-200 bg-gray-50">
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-600">
              Ready to generate {items.length} QR code{items.length !== 1 ? 's' : ''}
            </div>
            <div className="flex gap-3">
              <button
                onClick={onClose}
                className="px-6 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg font-medium transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleGenerate}
                disabled={isLoading || items.length === 0}
                className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-purple-500 to-blue-600 text-white rounded-lg font-medium hover:from-purple-600 hover:to-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                {isLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Check className="w-4 h-4" />
                    Generate All
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
