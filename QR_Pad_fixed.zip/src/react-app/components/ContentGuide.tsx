import { useState } from 'react';
import { 
  X, ChevronRight, ChevronDown, Search, QrCode, Scan, Palette, Shield, 
  Clock, Wifi, FileText, HelpCircle, AlertCircle, CheckCircle,
  Play, Star, Heart, Users, Zap, Award, Target, Layers
} from 'lucide-react';

interface ContentGuideProps {
  onClose: () => void;
}

const faqData = [
  {
    category: 'Getting Started',
    icon: QrCode,
    questions: [
      {
        q: 'What is QR Pad and what can I do with it?',
        a: 'QR Pad is a comprehensive QR code generator and scanner that allows you to create, customize, and manage QR codes for various purposes. You can generate QR codes for text, URLs, email addresses, phone numbers, WiFi credentials, contact information, and more. The app also includes a built-in scanner to read QR codes from your camera or uploaded images.'
      },
      {
        q: 'How do I create my first QR code?',
        a: 'Creating a QR code is simple: 1) Enter a descriptive title for your QR code, 2) Select the type of content (Text, URL, Email, etc.), 3) Enter the content you want to encode, 4) Choose a category for organization, 5) Optionally customize colors and styles, and 6) Click "Generate QR Code". Your QR code will be created and saved to your library.'
      },
      {
        q: 'Is QR Pad free to use?',
        a: 'Yes, QR Pad is completely free to use. You can create unlimited QR codes, access all customization features, use the scanner, organize with custom categories, and manage your QR code library without any cost or subscription fees.'
      },
      {
        q: 'Do I need to create an account to use QR Pad?',
        a: 'No account is required for basic usage. You can create and scan QR codes immediately. However, your QR codes are stored locally in your browser, so clearing browser data will remove them. For persistent storage across devices, we recommend bookmarking your important QR codes.'
      }
    ]
  },
  {
    category: 'QR Code Generation',
    icon: Palette,
    questions: [
      {
        q: 'What types of QR codes can I create?',
        a: 'QR Pad supports 7 different QR code types: 1) Plain Text - for any text content, 2) Website URL - for web links, 3) Email - for email addresses with optional subject/message, 4) Phone - for phone numbers, 5) SMS - for text messages with pre-filled content, 6) WiFi - for WiFi network credentials, and 7) Contact - for vCard contact information including name, phone, email, and address.'
      },
      {
        q: 'How do I customize the appearance of my QR codes?',
        a: 'QR Pad offers extensive customization options: Change foreground and background colors using the color picker, select from three QR code styles (Square, Circle, Rounded), choose corner styles (Square, Rounded, Circle), add borders (None, Thin, Thick), and embed logos from URLs. All changes are previewed in real-time before generation.'
      },
      {
        q: 'Can I add a logo to my QR code?',
        a: 'Yes! You can add a logo by enabling the "Add Logo" option in the QR Code Customization section and entering a URL to your logo image. The logo should be square and will be placed in the center of the QR code. Keep logos small (recommended max 20% of QR code size) to ensure the QR code remains scannable.'
      },
      {
        q: 'What is password protection and how does it work?',
        a: 'Password protection adds an extra security layer to your QR codes. When enabled, users must enter the correct password before accessing the QR code content. This is useful for sensitive information, private events, or restricted access content. Note that password protection is enforced by QR Pad and may not work with other QR readers.'
      },
      {
        q: 'Can I set an expiry date for my QR codes?',
        a: 'Yes, you can set an expiry date in the Advanced Options. After the specified date and time, the QR code will no longer be accessible through QR Pad. This is useful for time-limited offers, event tickets, or temporary access codes. The QR code image itself doesn\'t change, but the content becomes inaccessible.'
      }
    ]
  },
  {
    category: 'Custom Categories',
    icon: Layers,
    questions: [
      {
        q: 'How do I create custom categories?',
        a: 'Click "Add Custom Category" in the category selection area when creating a QR code. Enter a category name, choose an emoji icon, select a color, and click "Create Category". Your custom category will appear alongside default categories and can be used for organizing QR codes by your specific needs.'
      },
      {
        q: 'Can I delete custom categories?',
        a: 'Yes, you can delete custom categories by hovering over them in the category selection and clicking the red delete button. Note that deleting a category won\'t delete the QR codes in that category - they\'ll just become uncategorized.'
      },
      {
        q: 'How many custom categories can I create?',
        a: 'There\'s no limit to the number of custom categories you can create. Create as many as needed to organize your QR codes effectively - for example, "Work Projects", "Family Events", "Marketing Campaigns", "Personal Docs", etc.'
      },
      {
        q: 'What are some good examples of custom categories?',
        a: 'Popular custom categories include: "Client Projects" for business use, "Medical Records" for health information, "Recipes" for cooking QR codes, "Property Listings" for real estate, "Class Materials" for education, "Event Tickets" for entertainment, "Emergency Contacts" for safety, and "Portfolio Items" for creative professionals.'
      }
    ]
  },
  {
    category: 'QR Code Scanning',
    icon: Scan,
    questions: [
      {
        q: 'How do I scan QR codes with QR Pad?',
        a: 'Click the "Scan" button in the header to open the QR scanner. You can either use your device camera to scan QR codes in real-time or upload an image file containing a QR code. The scanner automatically detects and decodes QR codes, showing you the content and providing appropriate actions (open URLs, dial numbers, etc.).'
      },
      {
        q: 'What devices and browsers support the QR scanner?',
        a: 'The camera scanner works on most modern devices with cameras including smartphones, tablets, and computers with webcams. It requires browser permission to access your camera. The image upload scanner works on all devices and browsers. For best results, use updated versions of Chrome, Safari, Firefox, or Edge.'
      },
      {
        q: 'Why won\'t my camera work in the scanner?',
        a: 'Common issues include: Browser permission denied (check browser settings), no camera available on device, camera being used by another application, or insufficient lighting. Try refreshing the page, checking browser permissions, closing other camera apps, or using the "Upload Image" option instead.'
      },
      {
        q: 'Can I scan damaged or poor quality QR codes?',
        a: 'QR codes have built-in error correction, so minor damage or poor quality can often be handled. For best results: ensure good lighting, hold the camera steady, get close enough that the QR code fills most of the camera view, and clean the camera lens. If scanning fails, try the upload image option with a clearer photo.'
      }
    ]
  },
  {
    category: 'QR Library Management',
    icon: FileText,
    questions: [
      {
        q: 'How do I organize my QR code library?',
        a: 'Your QR library offers multiple organization tools: Use the search bar to find QR codes by title or content, filter by category (default or custom), sort by creation date, scan count, or name, switch between grid and list views, and use category stats to see QR code distribution across categories.'
      },
      {
        q: 'Can I edit QR codes after creating them?',
        a: 'Currently, QR codes cannot be edited after creation because changing the content would require generating a new QR code with different patterns. To update a QR code, create a new one with the updated information and delete the old one if needed.'
      },
      {
        q: 'How do I download QR codes to my device?',
        a: 'Click the eye icon on any QR code card to open the detail view, then use the "Download" button to save the QR code as a PNG image to your device. The downloaded image can be printed, shared, or used in other applications.'
      },
      {
        q: 'What information is tracked for each QR code?',
        a: 'For each QR code, QR Pad tracks: creation date and time, scan count (how many times it\'s been scanned), title and content, category assignment, customization settings (colors, style, logo), security settings (password protection, expiry), and last updated timestamp.'
      },
      {
        q: 'Can I export or backup my QR code library?',
        a: 'Currently, QR codes are stored locally in your browser. To backup important QR codes, download them individually using the download feature. For bulk backup, you can take screenshots of your library or manually save the important QR code images.'
      }
    ]
  },
  {
    category: 'Technical & Troubleshooting',
    icon: HelpCircle,
    questions: [
      {
        q: 'What image formats are supported for logo upload?',
        a: 'QR Pad accepts logo URLs pointing to common image formats including PNG, JPG, JPEG, GIF, and SVG. The logo should be accessible via a public URL (starting with https://). For best results, use square images with transparent backgrounds in PNG format.'
      },
      {
        q: 'Why do my QR codes look blurry or pixelated?',
        a: 'QR codes are generated as vector-based images that scale well, but display quality depends on your screen resolution and zoom level. For printing or high-resolution use, download the QR code and use image editing software to resize it to your desired dimensions while maintaining aspect ratio.'
      },
      {
        q: 'What happens if I clear my browser data?',
        a: 'Clearing browser data (cookies, local storage) will delete all your QR codes and custom categories since they\'re stored locally. Before clearing browser data, download important QR codes and note down your custom category settings to recreate them if needed.'
      },
      {
        q: 'Are there any limitations on QR code content?',
        a: 'QR codes have capacity limits based on content type and error correction level. Generally, you can store up to 4,296 alphanumeric characters or 2,953 bytes of binary data. Longer content may result in denser QR codes that are harder to scan. For optimal scanning, keep content concise.'
      },
      {
        q: 'How do I report bugs or suggest features?',
        a: 'We welcome feedback! If you encounter bugs, note the steps to reproduce the issue, your browser and device information, and any error messages. For feature suggestions, describe your use case and how the feature would help. You can provide feedback through your browser\'s built-in feedback tools.'
      }
    ]
  },
  {
    category: 'Best Practices & Tips',
    icon: Award,
    questions: [
      {
        q: 'What are the best practices for QR code design?',
        a: 'For optimal scanning: Use high contrast colors (dark foreground on light background), avoid complex backgrounds or patterns, ensure adequate quiet zone (white space) around the QR code, keep logos small and centered, test QR codes at the intended scanning distance, and use error correction appropriately for your use case.'
      },
      {
        q: 'How should I format different types of content?',
        a: 'URL: Use complete URLs with https://, Phone: Include country code (+1234567890), Email: Use mailto:email@domain.com format, WiFi: Use WIFI:T:WPA;S:NetworkName;P:Password;; format, SMS: Use SMSTO:+1234567890:Your message format, Contact: Use proper vCard format with all necessary fields.'
      },
      {
        q: 'What size should QR codes be for printing?',
        a: 'Minimum size depends on scanning distance: For handheld scanning (6-12 inches), use at least 2x2 cm (0.8x0.8 inches), for arm\'s length scanning (1-2 feet), use at least 3x3 cm (1.2x1.2 inches), for poster viewing (3+ feet), use at least 5x5 cm (2x2 inches). Always test at intended viewing distance.'
      },
      {
        q: 'How can I track QR code performance?',
        a: 'QR Pad tracks scan count for each QR code in your library. Use this data to see which QR codes are most popular, identify successful campaigns or content, optimize less-scanned QR codes, and make data-driven decisions about QR code placement and content.'
      },
      {
        q: 'What security considerations should I keep in mind?',
        a: 'Security tips: Don\'t include sensitive information in public QR codes, use password protection for confidential content, set expiry dates for time-sensitive information, regularly review and clean up old QR codes, verify URLs before sharing QR codes, and educate users about QR code safety (scanning only trusted sources).'
      }
    ]
  }
];

const howToGuides = [
  {
    id: 'create-basic-qr',
    title: 'Creating Your First QR Code',
    icon: QrCode,
    duration: '2 minutes',
    difficulty: 'Beginner',
    description: 'Learn how to create a basic QR code in just a few steps',
    steps: [
      {
        title: 'Enter QR Code Title',
        description: 'Give your QR code a descriptive name for easy identification in your library',
        tip: 'Use clear, specific titles like "Business Card - John Smith" or "WiFi - Office Network"'
      },
      {
        title: 'Select QR Type',
        description: 'Choose what type of content your QR code will contain from the dropdown menu',
        tip: 'Each type has a specific format - URL for websites, Email for email addresses, etc.'
      },
      {
        title: 'Add Your Content',
        description: 'Enter the actual content that will be encoded in the QR code',
        tip: 'Use the placeholder text as a guide for proper formatting'
      },
      {
        title: 'Choose Category',
        description: 'Select a category to organize your QR code or create a custom category',
        tip: 'Categories help you filter and organize your QR codes in the library'
      },
      {
        title: 'Generate QR Code',
        description: 'Click the "Generate QR Code" button to create your QR code',
        tip: 'Your QR code will be automatically saved to your library for future access'
      }
    ]
  },
  {
    id: 'customize-appearance',
    title: 'Customizing QR Code Appearance',
    icon: Palette,
    duration: '5 minutes',
    difficulty: 'Intermediate',
    description: 'Make your QR codes stand out with custom colors, styles, and logos',
    steps: [
      {
        title: 'Open QR Customization',
        description: 'Click "QR Code Customization" section while creating a QR code',
        tip: 'All customization options provide real-time preview'
      },
      {
        title: 'Choose Colors',
        description: 'Select foreground (QR pattern) and background colors using color picker',
        tip: 'Ensure high contrast between foreground and background for better scanning'
      },
      {
        title: 'Select Style',
        description: 'Choose from Square, Circle, or Rounded QR code styles',
        tip: 'Square style typically scans best, but other styles add visual appeal'
      },
      {
        title: 'Configure Corners',
        description: 'Set corner style (Square, Rounded, Circle) for the QR code patterns',
        tip: 'Rounded corners create a softer, more modern appearance'
      },
      {
        title: 'Add Border',
        description: 'Choose border style: None, Thin, or Thick',
        tip: 'Borders can help QR codes stand out on busy backgrounds'
      },
      {
        title: 'Embed Logo',
        description: 'Toggle "Add Logo" and enter a URL to your logo image',
        tip: 'Keep logos small and use square images with transparent backgrounds'
      },
      {
        title: 'Preview & Generate',
        description: 'Review the preview and generate your customized QR code',
        tip: 'Test scan your QR code to ensure customizations don\'t affect readability'
      }
    ]
  },
  {
    id: 'create-wifi-qr',
    title: 'Creating WiFi QR Codes',
    icon: Wifi,
    duration: '3 minutes',
    difficulty: 'Beginner',
    description: 'Allow guests to connect to your WiFi network instantly',
    steps: [
      {
        title: 'Select WiFi Type',
        description: 'Choose "WiFi" from the QR Type dropdown menu',
        tip: 'WiFi QR codes automatically connect devices without typing passwords'
      },
      {
        title: 'Enter Network Details',
        description: 'Use format: WIFI:T:WPA;S:NetworkName;P:Password;; replacing NetworkName and Password',
        tip: 'T: specifies security type (WPA, WEP, or nopass for open networks)'
      },
      {
        title: 'Security Types',
        description: 'Use WPA for WPA/WPA2 networks, WEP for older WEP networks, or nopass for open networks',
        tip: 'Most modern networks use WPA security - check your router settings if unsure'
      },
      {
        title: 'Example Format',
        description: 'Example: WIFI:T:WPA;S:MyHomeNetwork;P:MyPassword123;;',
        tip: 'Don\'t forget the double semicolon at the end - it\'s required for proper formatting'
      },
      {
        title: 'Test Connection',
        description: 'Generate the QR code and test it with a mobile device',
        tip: 'Android and iOS devices natively support WiFi QR codes in their camera apps'
      }
    ]
  },
  {
    id: 'organize-library',
    title: 'Organizing Your QR Library',
    icon: FileText,
    duration: '4 minutes',
    difficulty: 'Beginner',
    description: 'Keep your QR codes organized with categories, search, and filters',
    steps: [
      {
        title: 'Use Default Categories',
        description: 'Assign QR codes to default categories like Personal, Business, Shopping, etc.',
        tip: 'Consistent categorization makes finding QR codes much easier'
      },
      {
        title: 'Create Custom Categories',
        description: 'Click "Add Custom Category" to create categories specific to your needs',
        tip: 'Use categories like "Client Projects", "Event Tickets", or "Emergency Contacts"'
      },
      {
        title: 'Search Your Library',
        description: 'Use the search bar to find QR codes by title or content',
        tip: 'Search works across all text fields, including QR code content'
      },
      {
        title: 'Filter by Category',
        description: 'Use the category filter dropdown to show only QR codes from specific categories',
        tip: 'Combine category filters with search for precise results'
      },
      {
        title: 'Sort Your Codes',
        description: 'Sort by Latest, Most Scanned, or Name A-Z to arrange your library',
        tip: '"Most Scanned" helps identify your most popular QR codes'
      },
      {
        title: 'Switch View Modes',
        description: 'Toggle between grid and list views using the view mode buttons',
        tip: 'Grid view shows more QR codes at once, list view shows more details'
      }
    ]
  },
  {
    id: 'scan-qr-codes',
    title: 'Scanning QR Codes',
    icon: Scan,
    duration: '2 minutes',
    difficulty: 'Beginner',
    description: 'Learn how to scan QR codes using camera or image upload',
    steps: [
      {
        title: 'Open QR Scanner',
        description: 'Click the "Scan" button in the header to open the QR code scanner',
        tip: 'The scanner works with both camera input and uploaded images'
      },
      {
        title: 'Grant Camera Permission',
        description: 'Allow browser access to your camera when prompted',
        tip: 'Camera permission is required for real-time scanning'
      },
      {
        title: 'Position QR Code',
        description: 'Hold your device steady and position the QR code within the camera frame',
        tip: 'Ensure good lighting and get close enough for the QR code to fill most of the frame'
      },
      {
        title: 'Automatic Detection',
        description: 'The scanner automatically detects and decodes QR codes',
        tip: 'No need to press any buttons - detection is instant when a QR code is found'
      },
      {
        title: 'Upload Image Option',
        description: 'Alternatively, click "Upload Image" to scan QR codes from saved photos',
        tip: 'Useful for scanning QR codes from screenshots or when camera isn\'t available'
      },
      {
        title: 'View Results',
        description: 'Scanned content appears in a modal with appropriate action buttons',
        tip: 'URLs will have "Open" buttons, phone numbers "Call" buttons, etc.'
      }
    ]
  },
  {
    id: 'security-features',
    title: 'Using Security Features',
    icon: Shield,
    duration: '6 minutes',
    difficulty: 'Advanced',
    description: 'Protect your QR codes with passwords and expiry dates',
    steps: [
      {
        title: 'Enable Advanced Options',
        description: 'Click "Advanced Options" when creating a QR code to access security features',
        tip: 'Security features add an extra layer of protection to sensitive content'
      },
      {
        title: 'Set Password Protection',
        description: 'Toggle "Password Protection" and enter a secure password',
        tip: 'Use strong passwords with a mix of letters, numbers, and symbols'
      },
      {
        title: 'Choose Expiry Date',
        description: 'Set an expiry date and time using the date/time picker',
        tip: 'Useful for time-limited offers, event tickets, or temporary access'
      },
      {
        title: 'Understand Limitations',
        description: 'Password protection and expiry work only within QR Pad scanner',
        tip: 'Other QR scanners will show the raw content without security restrictions'
      },
      {
        title: 'Test Security',
        description: 'Generate the QR code and test the security features',
        tip: 'Always test password and expiry functionality before sharing'
      },
      {
        title: 'Manage Passwords',
        description: 'Keep passwords secure and share them through secure channels',
        tip: 'Consider using different passwords for different security levels'
      }
    ]
  }
];

const features = [
  {
    icon: QrCode,
    title: 'Multiple QR Types',
    description: 'Generate QR codes for text, URLs, email, phone, SMS, WiFi, and contact information',
    benefits: ['7 different QR code types', 'Optimized for each content type', 'Smart format validation', 'Copy-paste friendly']
  },
  {
    icon: Palette,
    title: 'Advanced Customization',
    description: 'Customize colors, styles, borders, corners, and embed logos for branded QR codes',
    benefits: ['Custom colors & styles', 'Logo embedding', 'Multiple border options', 'Real-time preview']
  },
  {
    icon: Layers,
    title: 'Custom Categories',
    description: 'Create unlimited custom categories with personalized icons and colors',
    benefits: ['Unlimited categories', 'Custom icons & colors', 'Easy organization', 'Smart filtering']
  },
  {
    icon: Scan,
    title: 'Built-in Scanner',
    description: 'Scan QR codes using your camera or by uploading images from your device',
    benefits: ['Camera scanning', 'Image upload support', 'Automatic detection', 'Smart content handling']
  },
  {
    icon: Shield,
    title: 'Security Features',
    description: 'Protect QR codes with passwords and set expiry dates for time-limited access',
    benefits: ['Password protection', 'Expiry dates', 'Secure content', 'Access control']
  },
  {
    icon: FileText,
    title: 'Library Management',
    description: 'Organize, search, filter, and manage all your QR codes in one place',
    benefits: ['Smart search', 'Category filtering', 'Usage statistics', 'Export options']
  }
];

export default function ContentGuide({ onClose }: ContentGuideProps) {
  const [activeTab, setActiveTab] = useState<'features' | 'howto' | 'faq'>('features');
  const [selectedGuide, setSelectedGuide] = useState<string | null>(null);
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredFAQ = faqData.filter(category =>
    category.questions.some(q => 
      q.q.toLowerCase().includes(searchTerm.toLowerCase()) ||
      q.a.toLowerCase().includes(searchTerm.toLowerCase())
    )
  ).map(category => ({
    ...category,
    questions: category.questions.filter(q =>
      q.q.toLowerCase().includes(searchTerm.toLowerCase()) ||
      q.a.toLowerCase().includes(searchTerm.toLowerCase())
    )
  }));

  const selectedGuideData = howToGuides.find(guide => guide.id === selectedGuide);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-6xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 bg-gradient-to-r from-blue-500 to-purple-600 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
                <QrCode className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">QR Pad Complete Guide</h2>
                <p className="text-blue-100">Everything you need to know about QR Pad</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-blue-100 hover:text-white hover:bg-white hover:bg-opacity-20 rounded-lg transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Tabs */}
          <div className="mt-6 flex gap-1 bg-white bg-opacity-20 rounded-xl p-1">
            <button
              onClick={() => setActiveTab('features')}
              className={`flex-1 py-2 px-4 rounded-lg font-medium transition-all ${
                activeTab === 'features' ? 'bg-white text-blue-600' : 'text-blue-100 hover:text-white'
              }`}
            >
              <Star className="w-4 h-4 inline mr-2" />
              Features
            </button>
            <button
              onClick={() => setActiveTab('howto')}
              className={`flex-1 py-2 px-4 rounded-lg font-medium transition-all ${
                activeTab === 'howto' ? 'bg-white text-blue-600' : 'text-blue-100 hover:text-white'
              }`}
            >
              <Play className="w-4 h-4 inline mr-2" />
              How-To Guides
            </button>
            <button
              onClick={() => setActiveTab('faq')}
              className={`flex-1 py-2 px-4 rounded-lg font-medium transition-all ${
                activeTab === 'faq' ? 'bg-white text-blue-600' : 'text-blue-100 hover:text-white'
              }`}
            >
              <HelpCircle className="w-4 h-4 inline mr-2" />
              FAQ
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="h-[calc(90vh-200px)] overflow-y-auto">
          {/* Features Tab */}
          {activeTab === 'features' && (
            <div className="p-6">
              <div className="text-center mb-8">
                <h3 className="text-3xl font-bold text-gray-900 mb-4">
                  Powerful QR Code Generation & Management
                </h3>
                <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                  QR Pad is the ultimate tool for creating, customizing, and managing QR codes. 
                  Whether you're a business professional, marketer, educator, or casual user, 
                  QR Pad has everything you need.
                </p>
              </div>

              {/* Key Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                <div className="text-center p-4 bg-blue-50 rounded-xl">
                  <div className="text-2xl font-bold text-blue-600">7</div>
                  <div className="text-sm text-gray-600">QR Code Types</div>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-xl">
                  <div className="text-2xl font-bold text-purple-600">∞</div>
                  <div className="text-sm text-gray-600">Custom Categories</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-xl">
                  <div className="text-2xl font-bold text-green-600">100%</div>
                  <div className="text-sm text-gray-600">Free to Use</div>
                </div>
                <div className="text-center p-4 bg-orange-50 rounded-xl">
                  <div className="text-2xl font-bold text-orange-600">0</div>
                  <div className="text-sm text-gray-600">Account Required</div>
                </div>
              </div>

              {/* Features Grid */}
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {features.map((feature, index) => (
                  <div key={index} className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-shadow">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center mb-4">
                      <feature.icon className="w-6 h-6 text-white" />
                    </div>
                    <h4 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h4>
                    <p className="text-gray-600 mb-4">{feature.description}</p>
                    <ul className="space-y-1">
                      {feature.benefits.map((benefit, benefitIndex) => (
                        <li key={benefitIndex} className="flex items-center gap-2 text-sm text-gray-600">
                          <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                          {benefit}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>

              {/* Use Cases */}
              <div className="mt-12">
                <h4 className="text-2xl font-bold text-gray-900 mb-6 text-center">Perfect For</h4>
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {[
                    { icon: Users, title: 'Business', desc: 'Marketing campaigns, contact sharing, product info' },
                    { icon: Heart, title: 'Personal', desc: 'WiFi sharing, contact cards, event invites' },
                    { icon: Target, title: 'Education', desc: 'Course materials, assignments, resource links' },
                    { icon: Zap, title: 'Events', desc: 'Tickets, schedules, venue information, feedback' }
                  ].map((useCase, index) => (
                    <div key={index} className="text-center p-4 bg-gray-50 rounded-xl">
                      <useCase.icon className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                      <h5 className="font-semibold text-gray-900 mb-1">{useCase.title}</h5>
                      <p className="text-xs text-gray-600">{useCase.desc}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* How-To Guides Tab */}
          {activeTab === 'howto' && (
            <div className="p-6">
              {selectedGuide ? (
                <div>
                  {/* Guide Header */}
                  <div className="flex items-center gap-4 mb-6">
                    <button
                      onClick={() => setSelectedGuide(null)}
                      className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                      <ChevronRight className="w-5 h-5 rotate-180" />
                    </button>
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold text-gray-900">{selectedGuideData?.title}</h3>
                      <div className="flex items-center gap-4 mt-1 text-sm text-gray-600">
                        <span className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {selectedGuideData?.duration}
                        </span>
                        <span className="flex items-center gap-1">
                          <Target className="w-4 h-4" />
                          {selectedGuideData?.difficulty}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Guide Description */}
                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
                    <p className="text-blue-800">{selectedGuideData?.description}</p>
                  </div>

                  {/* Guide Steps */}
                  <div className="space-y-6">
                    {selectedGuideData?.steps.map((step, index) => (
                      <div key={index} className="flex gap-4">
                        <div className="w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-semibold flex-shrink-0">
                          {index + 1}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900 mb-2">{step.title}</h4>
                          <p className="text-gray-700 mb-3">{step.description}</p>
                          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                            <div className="flex items-start gap-2">
                              <AlertCircle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                              <p className="text-sm text-yellow-800">
                                <strong>Tip:</strong> {step.tip}
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div>
                  <div className="text-center mb-8">
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">Step-by-Step Guides</h3>
                    <p className="text-gray-600">Learn how to use every feature of QR Pad</p>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    {howToGuides.map((guide) => (
                      <div
                        key={guide.id}
                        onClick={() => setSelectedGuide(guide.id)}
                        className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-all cursor-pointer group"
                      >
                        <div className="flex items-start gap-4">
                          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                            <guide.icon className="w-6 h-6 text-white" />
                          </div>
                          <div className="flex-1">
                            <h4 className="text-lg font-semibold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                              {guide.title}
                            </h4>
                            <p className="text-gray-600 text-sm mb-3">{guide.description}</p>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-4 text-xs text-gray-500">
                                <span className="flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  {guide.duration}
                                </span>
                                <span className={`px-2 py-1 rounded-full text-xs ${
                                  guide.difficulty === 'Beginner' ? 'bg-green-100 text-green-700' :
                                  guide.difficulty === 'Intermediate' ? 'bg-yellow-100 text-yellow-700' :
                                  'bg-red-100 text-red-700'
                                }`}>
                                  {guide.difficulty}
                                </span>
                              </div>
                              <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-blue-500 transition-colors" />
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* FAQ Tab */}
          {activeTab === 'faq' && (
            <div className="p-6">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Frequently Asked Questions</h3>
                <p className="text-gray-600">Find answers to common questions about QR Pad</p>
              </div>

              {/* Search */}
              <div className="relative mb-6">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search FAQ..."
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                />
              </div>

              {/* FAQ Categories */}
              <div className="space-y-4">
                {filteredFAQ.map((category) => (
                  <div key={category.category} className="bg-white border border-gray-200 rounded-xl overflow-hidden">
                    <button
                      onClick={() => setExpandedCategory(expandedCategory === category.category ? null : category.category)}
                      className="w-full p-6 text-left hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <category.icon className="w-5 h-5 text-blue-500" />
                          <span className="font-semibold text-gray-900">{category.category}</span>
                          <span className="text-sm text-gray-500">({category.questions.length} questions)</span>
                        </div>
                        <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${
                          expandedCategory === category.category ? 'rotate-180' : ''
                        }`} />
                      </div>
                    </button>

                    {expandedCategory === category.category && (
                      <div className="border-t border-gray-200">
                        {category.questions.map((qa, index) => (
                          <div key={index} className="p-6 border-b border-gray-100 last:border-b-0">
                            <h4 className="font-medium text-gray-900 mb-3">{qa.q}</h4>
                            <p className="text-gray-600 leading-relaxed">{qa.a}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {filteredFAQ.length === 0 && searchTerm && (
                <div className="text-center py-12">
                  <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h4 className="text-lg font-medium text-gray-900 mb-2">No results found</h4>
                  <p className="text-gray-600">Try different search terms or browse all categories</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
