import { useState } from 'react';
import { QrCode, Palette, Shield, Clock, Sparkles, Image, Square, Circle, CornerUpRight, Plus, Trash2, Bookmark } from 'lucide-react';
import { QRType, QRCategory, CreateQRCodeType, CategoryIcons } from '@/shared/types';
import { useCustomCategories } from '@/react-app/hooks/useCustomCategories';
import CustomCategoryModal from './CustomCategoryModal';

interface QRGeneratorProps {
  onGenerate: (qrData: CreateQRCodeType) => void;
  isLoading: boolean;
  onShowTemplates?: () => void;
}

export default function QRGenerator({ onGenerate, isLoading, onShowTemplates }: QRGeneratorProps) {
  const [formData, setFormData] = useState<CreateQRCodeType>({
    title: '',
    content: '',
    qr_type: 'text',
    category: 'personal',
    is_password_protected: false,
    password: '',
    expires_at: '',
    is_dynamic: false,
    custom_color: '#000000',
    qr_style: 'square',
    background_color: '#FFFFFF',
    has_logo: false,
    logo_url: '',
    border_style: 'none',
    corner_style: 'square'
  });

  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showCustomization, setShowCustomization] = useState(false);
  const [showCustomCategoryModal, setShowCustomCategoryModal] = useState(false);
  const { customCategories, createCustomCategory, deleteCustomCategory } = useCustomCategories();

  const qrTypes: { value: QRType; label: string; placeholder: string }[] = [
    { value: 'text', label: 'Text', placeholder: 'Enter your text here...' },
    { value: 'url', label: 'Website URL', placeholder: 'https://example.com' },
    { value: 'email', label: 'Email', placeholder: 'mailto:example@email.com' },
    { value: 'phone', label: 'Phone', placeholder: '+1234567890' },
    { value: 'sms', label: 'SMS', placeholder: 'SMSTO:+1234567890:Your message' },
    { value: 'wifi', label: 'WiFi', placeholder: 'WIFI:T:WPA;S:NetworkName;P:Password;;' },
    { value: 'contact', label: 'Contact', placeholder: 'BEGIN:VCARD\nVERSION:3.0\nFN:John Doe\nTEL:+1234567890\nEMAIL:john@example.com\nEND:VCARD' }
  ];

  const categories: { value: QRCategory; label: string }[] = [
    { value: 'personal', label: 'Personal' },
    { value: 'business', label: 'Business' },
    { value: 'shopping', label: 'Shopping' },
    { value: 'study', label: 'Study' },
    { value: 'travel', label: 'Travel' },
    { value: 'events', label: 'Events' },
    { value: 'social', label: 'Social' },
    { value: 'other', label: 'Other' }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate(formData);
  };

  const handleCreateCustomCategory = async (categoryData: any) => {
    const newCategory = await createCustomCategory(categoryData);
    if (newCategory) {
      setFormData(prev => ({ ...prev, custom_category_id: newCategory.id, category: undefined }));
      setShowCustomCategoryModal(false);
    }
  };

  const currentQrType = qrTypes.find(type => type.value === formData.qr_type);

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
            <QrCode className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Generate QR Code</h2>
            <p className="text-gray-600">Create your custom QR code with advanced features</p>
          </div>
        </div>
        {onShowTemplates && (
          <button
            onClick={onShowTemplates}
            className="flex items-center gap-2 px-4 py-2 bg-purple-50 hover:bg-purple-100 text-purple-600 rounded-xl font-medium transition-colors"
          >
            <Bookmark className="w-4 h-4" />
            Templates
          </button>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Title */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Title *
          </label>
          <input
            type="text"
            value={formData.title}
            onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
            placeholder="Give your QR code a name"
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            required
          />
        </div>

        {/* QR Type */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            QR Type *
          </label>
          <select
            value={formData.qr_type}
            onChange={(e) => setFormData(prev => ({ ...prev, qr_type: e.target.value as QRType }))}
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
          >
            {qrTypes.map(type => (
              <option key={type.value} value={type.value}>
                {type.label}
              </option>
            ))}
          </select>
        </div>

        {/* Content */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Content *
          </label>
          <textarea
            value={formData.content}
            onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
            placeholder={currentQrType?.placeholder}
            rows={4}
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
            required
          />
        </div>

        {/* Category */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Category
          </label>
          <div className="space-y-3">
            {/* Default Categories */}
            <div className="grid grid-cols-4 gap-2">
              {categories.map(category => (
                <button
                  key={category.value}
                  type="button"
                  onClick={() => setFormData(prev => ({ ...prev, category: category.value, custom_category_id: undefined }))}
                  className={`p-3 rounded-xl border-2 transition-all text-center ${
                    formData.category === category.value && !formData.custom_category_id
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="text-2xl mb-1">{CategoryIcons[category.value]}</div>
                  <div className="text-xs font-medium text-gray-700">{category.label}</div>
                </button>
              ))}
            </div>

            {/* Custom Categories */}
            {customCategories.length > 0 && (
              <div>
                <div className="text-xs font-medium text-gray-500 mb-2 uppercase tracking-wide">Custom Categories</div>
                <div className="grid grid-cols-4 gap-2">
                  {customCategories.map(category => (
                    <div key={category.id} className="relative group">
                      <button
                        type="button"
                        onClick={() => setFormData(prev => ({ ...prev, custom_category_id: category.id, category: undefined }))}
                        className={`w-full p-3 rounded-xl border-2 transition-all text-center ${
                          formData.custom_category_id === category.id
                            ? 'border-purple-500 bg-purple-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="text-2xl mb-1">{category.icon}</div>
                        <div className="text-xs font-medium text-gray-700">{category.name}</div>
                      </button>
                      <button
                        type="button"
                        onClick={() => deleteCustomCategory(category.id)}
                        className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-600 flex items-center justify-center"
                        title="Delete category"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Add Custom Category Button */}
            <button
              type="button"
              onClick={() => setShowCustomCategoryModal(true)}
              className="w-full p-3 border-2 border-dashed border-gray-300 rounded-xl hover:border-purple-400 hover:bg-purple-50 transition-all text-center group"
            >
              <div className="flex items-center justify-center gap-2 text-gray-500 group-hover:text-purple-600">
                <Plus className="w-4 h-4" />
                <span className="text-sm font-medium">Add Custom Category</span>
              </div>
            </button>
          </div>
        </div>

        {/* Advanced Options */}
        <div className="border-t border-gray-200 pt-6">
          <button
            type="button"
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 font-medium transition-colors"
          >
            <Sparkles className="w-4 h-4" />
            Advanced Options
          </button>

          {showAdvanced && (
            <div className="mt-4 space-y-4 p-4 bg-gray-50 rounded-xl">
              {/* Password Protection */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-gray-600" />
                  <span className="text-sm font-medium text-gray-700">Password Protection</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.is_password_protected}
                    onChange={(e) => setFormData(prev => ({ 
                      ...prev, 
                      is_password_protected: e.target.checked,
                      password: e.target.checked ? prev.password : ''
                    }))}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>

              {formData.is_password_protected && (
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                  placeholder="Enter password"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              )}

              {/* Custom Colors */}
              <div className="space-y-3">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Palette className="w-4 h-4 text-gray-600" />
                    <span className="text-sm font-medium text-gray-700">Foreground Color</span>
                  </div>
                  <input
                    type="color"
                    value={formData.custom_color}
                    onChange={(e) => setFormData(prev => ({ ...prev, custom_color: e.target.value }))}
                    className="w-12 h-8 border border-gray-300 rounded cursor-pointer"
                  />
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Square className="w-4 h-4 text-gray-600" />
                    <span className="text-sm font-medium text-gray-700">Background Color</span>
                  </div>
                  <input
                    type="color"
                    value={formData.background_color || '#FFFFFF'}
                    onChange={(e) => setFormData(prev => ({ ...prev, background_color: e.target.value }))}
                    className="w-12 h-8 border border-gray-300 rounded cursor-pointer"
                  />
                </div>
              </div>

              {/* Expiry Date */}
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-gray-600" />
                  <span className="text-sm font-medium text-gray-700">Expires At</span>
                </div>
                <input
                  type="datetime-local"
                  value={formData.expires_at}
                  onChange={(e) => setFormData(prev => ({ ...prev, expires_at: e.target.value }))}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
          )}
        </div>

        {/* QR Customization */}
        <div className="border-t border-gray-200 pt-6">
          <button
            type="button"
            onClick={() => setShowCustomization(!showCustomization)}
            className="flex items-center gap-2 text-purple-600 hover:text-purple-700 font-medium transition-colors"
          >
            <QrCode className="w-4 h-4" />
            QR Code Customization
          </button>

          {showCustomization && (
            <div className="mt-4 space-y-6 p-4 bg-purple-50 rounded-xl">
              {/* Style Options */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">QR Code Style</label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { value: 'square', label: 'Square', icon: Square },
                    { value: 'circle', label: 'Circle', icon: Circle },
                    { value: 'rounded', label: 'Rounded', icon: CornerUpRight }
                  ].map(style => (
                    <button
                      key={style.value}
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, qr_style: style.value }))}
                      className={`p-3 rounded-xl border-2 transition-all text-center ${
                        formData.qr_style === style.value
                          ? 'border-purple-500 bg-purple-100'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <style.icon className="w-6 h-6 mx-auto mb-1" />
                      <div className="text-xs font-medium text-gray-700">{style.label}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Corner Style */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">Corner Style</label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { value: 'square', label: 'Square' },
                    { value: 'rounded', label: 'Rounded' },
                    { value: 'circle', label: 'Circle' }
                  ].map(corner => (
                    <button
                      key={corner.value}
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, corner_style: corner.value }))}
                      className={`p-3 rounded-xl border-2 transition-all text-center ${
                        formData.corner_style === corner.value
                          ? 'border-purple-500 bg-purple-100'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="text-xs font-medium text-gray-700">{corner.label}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Border Style */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">Border Style</label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { value: 'none', label: 'None' },
                    { value: 'thin', label: 'Thin' },
                    { value: 'thick', label: 'Thick' }
                  ].map(border => (
                    <button
                      key={border.value}
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, border_style: border.value }))}
                      className={`p-3 rounded-xl border-2 transition-all text-center ${
                        formData.border_style === border.value
                          ? 'border-purple-500 bg-purple-100'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="text-xs font-medium text-gray-700">{border.label}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Logo Upload */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Image className="w-4 h-4 text-gray-600" />
                    <span className="text-sm font-medium text-gray-700">Add Logo</span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.has_logo || false}
                      onChange={(e) => setFormData(prev => ({ 
                        ...prev, 
                        has_logo: e.target.checked,
                        logo_url: e.target.checked ? prev.logo_url : ''
                      }))}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                  </label>
                </div>

                {formData.has_logo && (
                  <div className="space-y-3">
                    <input
                      type="url"
                      value={formData.logo_url || ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, logo_url: e.target.value }))}
                      placeholder="Enter logo URL (https://...)"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    />
                    <div className="text-xs text-gray-500">
                      Logo should be square and will be placed in the center of the QR code
                    </div>
                  </div>
                )}
              </div>

              {/* Preview */}
              <div className="text-center">
                <div className="inline-block p-4 bg-white rounded-xl shadow-sm border">
                  <div 
                    className="w-20 h-20 border-2 flex items-center justify-center text-xs text-gray-500"
                    style={{
                      backgroundColor: formData.background_color || '#FFFFFF',
                      borderColor: formData.custom_color,
                      borderRadius: formData.corner_style === 'circle' ? '50%' : formData.corner_style === 'rounded' ? '8px' : '0',
                      borderWidth: formData.border_style === 'thick' ? '3px' : formData.border_style === 'thin' ? '1px' : '0'
                    }}
                  >
                    QR Preview
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Generate Button */}
        <button
          type="submit"
          disabled={isLoading || !formData.title || !formData.content}
          className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-4 rounded-xl font-semibold text-lg hover:from-blue-600 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all transform hover:scale-[1.02] active:scale-[0.98]"
        >
          {isLoading ? 'Generating...' : 'Generate QR Code'}
        </button>
      </form>

      {/* Custom Category Modal */}
      {showCustomCategoryModal && (
        <CustomCategoryModal
          onClose={() => setShowCustomCategoryModal(false)}
          onCreateCategory={handleCreateCustomCategory}
          isLoading={isLoading}
        />
      )}
    </div>
  );
}
