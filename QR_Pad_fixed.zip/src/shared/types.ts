import z from "zod";

export const QRTypeSchema = z.enum([
  'text',
  'url',
  'email',
  'phone',
  'sms',
  'wifi',
  'contact',
  'file',
  'voice'
]);

export const QRCategorySchema = z.enum([
  'personal',
  'business',
  'shopping',
  'study',
  'travel',
  'events',
  'social',
  'other'
]);

export const CustomCategorySchema = z.object({
  id: z.number(),
  name: z.string(),
  icon: z.string(),
  color: z.string(),
  created_at: z.string(),
  updated_at: z.string()
});

export const CreateCustomCategorySchema = z.object({
  name: z.string().min(1, "Category name is required"),
  icon: z.string().default('📁'),
  color: z.string().default('#6B7280')
});

export const QRCodeSchema = z.object({
  id: z.number(),
  title: z.string(),
  content: z.string(),
  qr_type: QRTypeSchema,
  category: QRCategorySchema.optional(),
  custom_category_id: z.number().optional(),
  qr_data_url: z.string().optional(),
  is_password_protected: z.boolean(),
  password_hash: z.string().optional(),
  expires_at: z.string().optional(),
  scan_count: z.number(),
  is_dynamic: z.boolean(),
  geo_latitude: z.number().optional(),
  geo_longitude: z.number().optional(),
  geo_radius: z.number().optional(),
  custom_color: z.string(),
  custom_logo: z.string().optional(),
  created_at: z.string(),
  updated_at: z.string()
});

export const CreateQRCodeSchema = z.object({
  title: z.string().min(1, "Title is required"),
  content: z.string().min(1, "Content is required"),
  qr_type: QRTypeSchema,
  category: QRCategorySchema.optional(),
  custom_category_id: z.number().optional(),
  is_password_protected: z.boolean().default(false),
  password: z.string().optional(),
  expires_at: z.string().optional(),
  is_dynamic: z.boolean().default(false),
  geo_latitude: z.number().optional(),
  geo_longitude: z.number().optional(),
  geo_radius: z.number().optional(),
  custom_color: z.string().default('#000000'),
  custom_logo: z.string().optional(),
  qr_style: z.string().optional(),
  background_color: z.string().optional(),
  has_logo: z.boolean().optional(),
  logo_url: z.string().optional(),
  border_style: z.string().optional(),
  corner_style: z.string().optional()
});

export const QRScanSchema = z.object({
  id: z.number(),
  qr_code_id: z.number(),
  scan_location: z.string().optional(),
  device_info: z.string().optional(),
  created_at: z.string(),
  updated_at: z.string()
});

export type QRType = z.infer<typeof QRTypeSchema>;
export type QRCategory = z.infer<typeof QRCategorySchema>;
export type QRCodeType = z.infer<typeof QRCodeSchema>;
export type CreateQRCodeType = z.infer<typeof CreateQRCodeSchema>;
export type QRScanType = z.infer<typeof QRScanSchema>;
export type CustomCategoryType = z.infer<typeof CustomCategorySchema>;
export type CreateCustomCategoryType = z.infer<typeof CreateCustomCategorySchema>;

export const CategoryColors = {
  personal: 'bg-blue-500',
  business: 'bg-green-500', 
  shopping: 'bg-yellow-500',
  study: 'bg-purple-500',
  travel: 'bg-indigo-500',
  events: 'bg-pink-500',
  social: 'bg-orange-500',
  other: 'bg-gray-500'
} as const;

export const CategoryIcons = {
  personal: '👤',
  business: '💼',
  shopping: '🛒',
  study: '📚',
  travel: '✈️',
  events: '🎉',
  social: '💬',
  other: '📋'
} as const;
