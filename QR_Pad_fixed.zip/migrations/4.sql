
ALTER TABLE qr_codes ADD COLUMN custom_category_id INTEGER;
