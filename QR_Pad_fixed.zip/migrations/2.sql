
ALTER TABLE qr_codes ADD COLUMN qr_style TEXT DEFAULT 'square';
ALTER TABLE qr_codes ADD COLUMN background_color TEXT DEFAULT '#FFFFFF';
ALTER TABLE qr_codes ADD COLUMN has_logo BOOLEAN DEFAULT 0;
ALTER TABLE qr_codes ADD COLUMN logo_url TEXT;
ALTER TABLE qr_codes ADD COLUMN border_style TEXT DEFAULT 'none';
ALTER TABLE qr_codes ADD COLUMN corner_style TEXT DEFAULT 'square';
