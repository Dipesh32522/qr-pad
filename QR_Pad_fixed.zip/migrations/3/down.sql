
DROP TABLE custom_categories;
