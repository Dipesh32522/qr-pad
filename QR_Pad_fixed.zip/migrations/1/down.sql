
DROP INDEX idx_qr_scans_qr_code_id;
DROP INDEX idx_qr_codes_created_at;
DROP INDEX idx_qr_codes_category;
DROP TABLE qr_scans;
DROP TABLE qr_codes;
