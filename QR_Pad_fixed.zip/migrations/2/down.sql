
ALTER TABLE qr_codes DROP COLUMN corner_style;
ALTER TABLE qr_codes DROP COLUMN border_style;
ALTER TABLE qr_codes DROP COLUMN logo_url;
ALTER TABLE qr_codes DROP COLUMN has_logo;
ALTER TABLE qr_codes DROP COLUMN background_color;
ALTER TABLE qr_codes DROP COLUMN qr_style;
