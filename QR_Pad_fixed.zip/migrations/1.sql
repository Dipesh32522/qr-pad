
CREATE TABLE qr_codes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  qr_type TEXT NOT NULL,
  category TEXT,
  qr_data_url TEXT,
  is_password_protected BOOLEAN DEFAULT 0,
  password_hash TEXT,
  expires_at DATETIME,
  scan_count INTEGER DEFAULT 0,
  is_dynamic BOOLEAN DEFAULT 0,
  geo_latitude REAL,
  geo_longitude REAL,
  geo_radius REAL,
  custom_color TEXT DEFAULT '#000000',
  custom_logo TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE qr_scans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  qr_code_id INTEGER NOT NULL,
  scan_location TEXT,
  device_info TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_qr_codes_category ON qr_codes(category);
CREATE INDEX idx_qr_codes_created_at ON qr_codes(created_at);
CREATE INDEX idx_qr_scans_qr_code_id ON qr_scans(qr_code_id);
