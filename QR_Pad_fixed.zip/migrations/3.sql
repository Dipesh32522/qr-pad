
CREATE TABLE custom_categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  icon TEXT DEFAULT '📁',
  color TEXT DEFAULT '#6B7280',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO custom_categories (name, icon, color) VALUES
('Work', '💼', '#059669'),
('Family', '👨‍👩‍👧‍👦', '#DC2626'),
('Health', '🏥', '#DC2626'),
('Finance', '💰', '#D97706'),
('Education', '🎓', '#7C3AED'),
('Sports', '⚽', '#059669'),
('Food', '🍽️', '#EA580C'),
('Music', '🎵', '#EC4899');
