
ALTER TABLE qr_codes DROP COLUMN custom_category_id;
